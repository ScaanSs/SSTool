﻿using System.Collections.Generic;
using System.Linq;

namespace SSTool
{
    static class Data
    {
        const string N = "https://www.nirsoft.net/utils/";
        const string EZ = "https://download.ericzimmermanstools.com/net9/";
        const string RAW = "https://raw.githubusercontent.com/";
        const string LILY = "https://raw.githubusercontent.com/praiselily/lilith-ps/main/";

        // GitHub release asset download URL.
        static string gh(string owner, string repo, string tag, string asset)
        {
            return "https://github.com/" + owner + "/" + repo + "/releases/download/" + tag + "/" + asset;
        }

        public static List<string> Sections()
        {
            return new List<string> {
                "OrbDiff", "Spokwn", "tonynoh", "Scripts", "RedLotus",
                "NirSoft", "EricZimmerman", "Others", "Dependencies", "Webs"
            };
        }

        public static string SectionInfo(string s)
        {
            bool es = L.Es;
            switch (s)
            {
                case "OrbDiff": return es ? "Herramientas de Orbdiff · github.com/Orbdiff" : "Tools by Orbdiff · github.com/Orbdiff";
                case "Spokwn": return es ? "Herramientas de spokwn · github.com/spokwn" : "Tools by spokwn · github.com/spokwn";
                case "tonynoh": return es ? "Herramientas de tonynoh · github.com/MeowTonynoh" : "Tools by tonynoh · github.com/MeowTonynoh";
                case "Scripts": return es ? "Scripts de PowerShell (se ejecutan en memoria, sin rastro)" : "PowerShell scripts (run in memory, no trace)";
                case "RedLotus": return es ? "Programas de RedLotus · github.com/itzicehere" : "Programs by RedLotus · github.com/itzicehere";
                case "NirSoft": return es ? "Utilidades de NirSoft · nirsoft.net" : "NirSoft utilities · nirsoft.net";
                case "EricZimmerman": return es ? "Herramientas forenses de Eric Zimmerman (net9) · ericzimmerman.github.io" : "Eric Zimmerman forensic tools (net9) · ericzimmerman.github.io";
                case "Others": return es ? "Programas de otros desarrolladores" : "Programs by other developers";
                case "Dependencies": return es ? "Runtimes que necesitan algunas herramientas" : "Runtimes required by some tools";
                case "Webs": return es ? "Webs para descargar programas forenses y de análisis" : "Websites to download forensic / analysis programs";
            }
            return s;
        }

        public static List<Tool> All()
        {
            var t = new List<Tool>();

            // ---------- OrbDiff ----------
            t.Add(new Tool("OrbDiff", "PrefetchView++", "Prefetch parser: firmas, imports, YARA, UsnJrnl", "Prefetch parser: signatures, imports, YARA, UsnJrnl", gh("Orbdiff", "PrefetchView", "v1.6.8", "pv++.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "BAMReveal", "Parsea BAM, convierte paths, firmas, UsnJrnl", "Parses BAM, converts paths, signatures, UsnJrnl", gh("Orbdiff", "BAMReveal", "v1.3.1", "BAMReveal.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "AmcacheParser", "Parsea Amcache, firmas y YARA", "Parses Amcache, signatures and YARA", gh("Orbdiff", "AmcacheParser", "v1.0", "AmcacheParser.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "JournalParser", "Parsea entradas del USN Journal NTFS", "Parses NTFS USN Journal entries", gh("Orbdiff", "JournalParser", "v1.2", "JournalParser.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "CheckDeletedUSN", "Detecta si el USN Journal fue borrado", "Detects whether the USN Journal was deleted", gh("Orbdiff", "CheckDeletedUSN", "v0.2.1", "CheckDeletedUSN.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "Fileless", "Detecta fileless por event logs + análisis RAM", "Detects fileless via event logs + RAM analysis", gh("Orbdiff", "Fileless", "v1.3", "fileless.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "JARParser", "Parsea prefetch de .jar, DcomLaunch, borrados", "Parses .jar prefetch, DcomLaunch, deleted files", gh("Orbdiff", "JARParser", "v1.2", "JARParser.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "PFTrace", "Prefetch de Rundll32/Regsvr32 + imports", "Rundll32/Regsvr32 prefetch + imports", gh("Orbdiff", "PFTrace", "v1.0.1", "PFTrace.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "InjGen", "Detecta inyecciones JNI/JVMTI en el cliente JVM", "Detects JNI/JVMTI injections in the JVM client", gh("Orbdiff", "InjGen", "fork", "InjGen.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "DPS-Analyzer", "Dumpea memoria DPS y la filtra en archivos", "Dumps DPS memory and filters it into files", gh("Orbdiff", "DPS-Analyzer", "v1.1", "dpsanalyzer.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "USBDetector", "Detector USB (cfgmgr32, setupAPI, devicehunt)", "USB detector (cfgmgr32, setupAPI, devicehunt)", gh("Orbdiff", "USBDetector", "v1.1", "USBDetector.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "UserAssistView", "Parsea UserAssist, firmas, UsnJrnl, YARA", "Parses UserAssist, signatures, UsnJrnl, YARA", gh("Orbdiff", "UserAssistView", "v1.0", "UserAssistView.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "StringsParser", "Strings de AppInfo/DiagTrack o un dump + YARA", "Strings from AppInfo/DiagTrack or a dump + YARA", gh("Orbdiff", "StringsParser", "v1.2.1b", "stringsparser.1.2.1b.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "BAM-CheckRestart", "Detecta la fecha de creación del BAM", "Detects the BAM creation date", gh("Orbdiff", "BAM-CheckRestart", "v2.0.2", "BAMCheckRestart.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "MFT-HardLink", "Detecta hardlinks usando el $MFT", "Detects hardlinks using the $MFT", gh("Orbdiff", "MFT-HardLink", "v1.2", "HardLink.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "MFTParser", "Parsea el $MFT a CSV (para TLE)", "Parses the $MFT to CSV (for TLE)", gh("Orbdiff", "MFTParser", "v0.1", "mftparser.exe"), "dl"));
            t.Add(new Tool("OrbDiff", "WebHollowing", "Revisa dominios contra logs de Security y DNS", "Checks domains against Security and DNS logs", gh("Orbdiff", "WebHollowing", "v1.0", "web.hollowing.exe"), "dl"));

            // ---------- Spokwn ----------
            t.Add(new Tool("Spokwn", "JournalTrace", "Parsea entradas del journal NTFS", "Parses NTFS journal entries", gh("spokwn", "JournalTrace", "1.2", "JournalTrace.exe"), "dl"));
            t.Add(new Tool("Spokwn", "PcaSvcExecuted", "Ejecución vía pcasvc + firmas y YARA", "Execution via pcasvc + signatures and YARA", gh("spokwn", "pcasvc-executed", "v0.8.7", "PcaSvcExecuted.exe"), "dl"));
            t.Add(new Tool("Spokwn", "Espouken", "Herramienta multiuso de SS", "Multi-purpose SS tool", gh("spokwn", "Tool", "v1.1.3", "espouken.exe"), "dl"));
            t.Add(new Tool("Spokwn", "ProcessParser", "Strings de procesos + firmas y YARA", "Process strings + signatures and YARA", gh("spokwn", "process-parser", "v0.5.5", "ProcessParser.exe"), "dl"));
            t.Add(new Tool("Spokwn", "PathsParser", "Parsea paths de un .txt + firmas, YARA, replaces", "Parses paths from a .txt + signatures, YARA, replaces", gh("spokwn", "PathsParser", "v1.2", "PathsParser.exe"), "dl"));
            t.Add(new Tool("Spokwn", "ActivitiesCacheParser", "Ejecución vía activitiescache.db + YARA", "Execution via activitiescache.db + YARA", gh("spokwn", "ActivitiesCache-execution", "v0.6.5", "ActivitiesCacheParser.exe"), "dl"));
            t.Add(new Tool("Spokwn", "BamDeletedKeys", "Claves BAM borradas comparando con la hive", "Deleted BAM keys by comparing with the hive", gh("spokwn", "BamDeletedKeys", "v1.0", "BamDeletedKeys.exe"), "dl"));
            t.Add(new Tool("Spokwn", "PrefetchParser", "Parsea prefetch, firmas y generics", "Parses prefetch, signatures and generics", gh("spokwn", "prefetch-parser", "v1.5.5", "PrefetchParser.exe"), "dl"));
            t.Add(new Tool("Spokwn", "KernelLiveDumpTool", "Lee LiveKernel dumps y busca strings sospechosas", "Reads LiveKernel dumps and looks for suspicious strings", gh("spokwn", "KernelLiveDumpTool", "v1.1", "KernelLiveDumpTool.exe"), "dl"));
            t.Add(new Tool("Spokwn", "BAMParser", "Parsea BAM: firmas, last executed, YARA", "Parses BAM: signatures, last executed, YARA", gh("spokwn", "BAM-parser", "v1.2.9", "BAMParser.exe"), "dl"));
            t.Add(new Tool("Spokwn", "ReplaceParser", "Parser de replaces", "Replace parser", gh("spokwn", "Replaceparser", "v1.1-recode", "ReplaceParser.exe"), "dl"));

            // ---------- tonynoh ----------
            t.Add(new Tool("tonynoh", "MeowClientFucker", "Scanner de clientes", "Client scanner", gh("MeowTonynoh", "MeowClientFucker", "V1.1", "MeowClientFucker.exe"), "dl"));
            t.Add(new Tool("tonynoh", "MeowDoomsdayFucker", "Detector de Doomsday", "Doomsday detector", gh("MeowTonynoh", "MeowDoomsdayFucker", "V.1.6", "MeowDoomsdayFucker.exe"), "dl"));
            t.Add(new Tool("tonynoh", "MeowImportsChecker", "Comprueba imports de binarios", "Checks binary imports", gh("MeowTonynoh", "MeowImportsChecker", "MeowImportsChecker", "MeowImportsChecker.exe"), "dl"));
            t.Add(new Tool("tonynoh", "MeowNovowareFucker", "Detector de Novoware", "Novoware detector", gh("MeowTonynoh", "MeowNovowareFucker", "V2", "MeowNovowareFucker.exe"), "dl"));
            t.Add(new Tool("tonynoh", "MeowResolver", "Detecta y resuelve bypasses", "Detects and resolves bypasses", gh("MeowTonynoh", "MeowResolver", "v.1.1", "MeowResolver.exe"), "dl"));

            // ---------- Scripts (PowerShell, kind "ps"; "local" = bundled in SSTool.exe) ----------
            t.Add(new Tool("Scripts", "NTFS Artifacts (Scaan)", "Saca $LogFile y $I30 a CSV y los abre en Timeline Explorer", "Extracts $LogFile and $I30 to CSV and opens them in Timeline Explorer", "NTFS-Artifacts.ps1", "local")
                .From("https://raw.githubusercontent.com/ScaanSs/NTFS-Artifacts/main/NTFS-Artifacts.ps1"));
            t.Add(new Tool("Scripts", "AguaScript", "Script de SS (AguaConGas17)", "SS script (AguaConGas17)", RAW + "AguaConGas17/Powershells/main/aguascript.ps1", "ps"));
            // lilith-ps (praiselily): https://github.com/praiselily/lilith-ps
            t.Add(new Tool("Scripts", "Service-Enabler (lilith)", "Ventana para reactivar servicios clave (SysMain, PcaSvc, DPS, EventLog…)", "Window to re-enable key services (SysMain, PcaSvc, DPS, EventLog…)", LILY + "Service-Enabler.ps1", "ps")
                .Warn("Cambia servicios", "Changes services"));
            t.Add(new Tool("Scripts", "Services (lilith)", "Hora de arranque, estado de los servicios de SS y discos", "Boot time, SS service status and drives", LILY + "Services.ps1", "ps"));
            t.Add(new Tool("Scripts", "SchedulesV2 (lilith)", "Tareas programadas sospechosas o sin firmar", "Suspicious or unsigned scheduled tasks", LILY + "SchedulesV2.ps1", "ps"));
            t.Add(new Tool("Scripts", "Signed-Scheduled-Tasks (lilith)", "Tareas programadas con comprobación de firmas", "Scheduled tasks with signature checks", LILY + "Signed-Scheduled-Tasks", "ps"));
            t.Add(new Tool("Scripts", "ShellSearch (lilith)", "Busca comandos sospechosos en los logs de PowerShell", "Looks for suspicious commands in the PowerShell logs", LILY + "ShellSearch.ps1", "ps"));
            t.Add(new Tool("Scripts", "CommonDirectories (lilith)", "Archivos sin firma en System32, SysWOW64 y Temp", "Unsigned files in System32, SysWOW64 and Temp", LILY + "CommonDirectories.ps1", "ps")
                .Warn("Guarda en C:\\Screenshare", "Saves to C:\\Screenshare"));
            t.Add(new Tool("Scripts", "DoomsdayFinder (lilith)", "Busca el cliente Doomsday en el prefetch de javaw", "Looks for the Doomsday client in javaw prefetch", LILY + "DoomsdayFinder.ps1", "ps"));
            t.Add(new Tool("Scripts", "HarddiskConverter (lilith)", "Pasa rutas \\Device\\HarddiskVolume de diskpaths.txt a C:\\…", "Converts \\Device\\HarddiskVolume paths in diskpaths.txt to C:\\…", LILY + "HarddiskConverter.ps1", "ps"));
            t.Add(new Tool("Scripts", "Collector (lilith)", "Descarga tools de spokwn, Eric Zimmerman y NirSoft", "Downloads spokwn, Eric Zimmerman and NirSoft tools", LILY + "Collector.ps1", "ps")
                .Warn("Añade exclusión en Defender", "Adds a Defender exclusion"));
            t.Add(new Tool("Scripts", "Spokwn-Collect (lilith)", "Descarga las tools de spokwn más usadas", "Downloads the most used spokwn tools", LILY + "Spokwn-Collect.ps1", "ps")
                .Warn("Guarda en C:\\Screenshare", "Saves to C:\\Screenshare"));
            t.Add(new Tool("Scripts", "IHateScreensharing (lilith)", "Deshace bloqueos anti-SS: hosts, firewall, políticas, permisos de Prefetch…", "Undoes anti-SS blocks: hosts, firewall, policies, Prefetch permissions…", LILY + "IHateScreensharing.ps1", "ps")
                .Warn("Modifica el sistema", "Modifies the system"));
            t.Add(new Tool("Scripts", "DecryptBitlocker", "Detecta/clasifica volúmenes cifrados", "Detects/classifies encrypted volumes", RAW + "lea13245/decrypt-bitlocker/main/decrypt-bitlocker.ps1", "ps"));
            t.Add(new Tool("Scripts", "LogFileParser", "Parsea $LogFile de NTFS", "Parses the NTFS $LogFile", RAW + "AguaConGas17/Powershells/main/logfileparser.ps1", "ps"));
            t.Add(new Tool("Scripts", "ScheduledTasks", "Revisa tareas programadas", "Checks scheduled tasks", RAW + "AguaConGas17/Powershells/main/ScheduledTasks.ps1", "ps"));
            t.Add(new Tool("Scripts", "Pca-Files", "Analiza archivos PCA", "Analyzes PCA files", RAW + "AguaConGas17/Powershells/main/Pca-Files.ps1", "ps"));
            t.Add(new Tool("Scripts", "ClassLoaderDump", "Dump del class loader (JVM)", "Class loader dump (JVM)", RAW + "p1aegg/powershell/main/ClassLoaderDump.ps1", "ps"));
            t.Add(new Tool("Scripts", "HabibiModAnalyzer", "Analizador de mods", "Mod analyzer", RAW + "HadronCollision/PowershellScripts/main/HabibiModAnalyzer.ps1", "ps"));
            t.Add(new Tool("Scripts", "SignaturesParser (Orbdiff)", "Parser de firmas", "Signature parser", RAW + "Orbdiff/powershell/main/signaturesparser.ps1", "ps"));
            t.Add(new Tool("Scripts", "Signatures (spokwn)", "Comprobación de firmas", "Signature check", RAW + "spokwn/powershells/main/signatures.ps1", "ps"));
            t.Add(new Tool("Scripts", "BamParser (spokwn)", "Parser de BAM", "BAM parser", RAW + "spokwn/powershells/main/bamparser.ps1", "ps"));
            t.Add(new Tool("Scripts", "Streams (spokwn)", "Revisa Alternate Data Streams", "Checks Alternate Data Streams", RAW + "spokwn/powershells/main/Streams.ps1", "ps"));
            t.Add(new Tool("Scripts", "AnyDesk (spokwn)", "Rastro de AnyDesk", "AnyDesk traces", RAW + "spokwn/powershells/main/anydesk.ps1", "ps"));
            t.Add(new Tool("Scripts", "RedLotusBam", "BAM de RedLotus (PureIntent)", "RedLotus BAM (PureIntent)", RAW + "PureIntent/ScreenShare/main/RedLotusBam.ps1", "ps"));
            t.Add(new Tool("Scripts", "RedLotus Prefetch Integrity", "Integridad de prefetch", "Prefetch integrity", RAW + "bacanoicua/Screenshare/main/RedLotusPrefetchIntegrityAnalyzer.ps1", "ps"));
            t.Add(new Tool("Scripts", "SSITA ProcessInfo", "Info de procesos (ScreenShareITA)", "Process info (ScreenShareITA)", RAW + "ScreenShareITA/ScreenShare/main/SSITAProcessInfo.ps1", "ps"));
            t.Add(new Tool("Scripts", "JVM-Inspector (tonynoh)", "Inspecciona la JVM", "Inspects the JVM", RAW + "MeowTonynoh/Tonynoh-PS1/main/JVM-Inspector.ps1", "ps"));
            t.Add(new Tool("Scripts", "MeowModAnalyzer (tonynoh)", "Analizador de mods", "Mod analyzer", RAW + "MeowTonynoh/MeowModAnalyzer/main/MeowModAnalyzer.ps1", "ps"));
            t.Add(new Tool("Scripts", "DoomsDayDetector", "Detector de DoomsDay", "DoomsDay detector", RAW + "zedoonvm1/powershell-scripts/main/DoomsDayDetector.ps1", "ps"));

            // ---------- RedLotus ----------
            t.Add(new Tool("RedLotus", "RedLotus Downloader", "Descargador de archivos de RedLotus", "RedLotus file downloader", gh("itzicehere", "RedLotus-Tool-Downloader", "RL", "RedLotus.Downloader.exe"), "dl"));
            t.Add(new Tool("RedLotus", "AltChecker", "Comprobador de alts de RedLotus", "RedLotus alt checker", gh("itzicehere", "RedLotusAltChecker", "RL", "RedLotusAltChecker.exe"), "dl"));
            t.Add(new Tool("RedLotus", "Mod Analyzer", "Analizador de mods de RedLotus", "RedLotus mod analyzer", gh("itzicehere", "RedLotus-Mod-Analyzer", "RL", "RedLotusModAnalyzer.exe"), "dl"));
            t.Add(new Tool("RedLotus", "Task Sentinel", "Vigilante de tareas de RedLotus", "RedLotus task watcher", gh("itzicehere", "RedLotus-Task-Sentinel", "RL", "RedLotusTaskSentinel.exe"), "dl"));

            // ---------- NirSoft ----------
            t.Add(new Tool("NirSoft", "FullEventLogView", "Ver los registros de eventos de Windows", "View Windows event logs", N + "fulleventlogview-x64.zip", "dl"));
            t.Add(new Tool("NirSoft", "NetworkUsageView", "Monitoriza el uso de red", "Monitor network usage", N + "networkusageview-x64.zip", "dl"));
            t.Add(new Tool("NirSoft", "BrowserDownloadsView", "Historial de descargas del navegador", "View browser download history", N + "browserdownloadsview-x64.zip", "dl"));
            t.Add(new Tool("NirSoft", "AlternateStreamView", "Ver alternate data streams de NTFS", "View NTFS alternate data streams", N + "alternatestreamview-x64.zip", "dl"));
            t.Add(new Tool("NirSoft", "USBDeview", "Historial de dispositivos USB", "USB device history", N + "usbdeview-x64.zip", "dl"));
            t.Add(new Tool("NirSoft", "OpenSaveFilesView", "Historial de diálogos Abrir/Guardar", "View Open/Save dialog history", N + "opensavefilesview-x64.zip", "dl"));
            t.Add(new Tool("NirSoft", "ExecutedProgramsList", "Lista de programas ejecutados", "List executed programs", N + "executedprogramslist.zip", "dl"));
            t.Add(new Tool("NirSoft", "TaskSchedulerView", "Ver tareas programadas", "View scheduled tasks", N + "taskschedulerview-x64.zip", "dl"));
            t.Add(new Tool("NirSoft", "JumpListsView", "Ver Jump Lists de Windows", "View Windows Jump Lists", N + "jumplistsview.zip", "dl"));
            t.Add(new Tool("NirSoft", "WinPrefetchView", "Ver archivos Prefetch de Windows", "View Windows Prefetch files", N + "winprefetchview-x64.zip", "dl"));
            t.Add(new Tool("NirSoft", "RegScanner", "Escáner avanzado del registro", "Advanced registry scanner", N + "regscanner-x64.zip", "dl"));
            t.Add(new Tool("NirSoft", "ShellBagsView", "Ver entradas de ShellBags", "View ShellBags entries", N + "shellbagsview.zip", "dl"));
            t.Add(new Tool("NirSoft", "LastActivityView", "Línea de tiempo de la actividad del PC", "Timeline of PC activity", N + "lastactivityview.zip", "dl"));
            t.Add(new Tool("NirSoft", "UserAssistView", "Decodifica la clave UserAssist", "Decode UserAssist registry key", N + "userassistview.zip", "dl"));
            t.Add(new Tool("NirSoft", "BrowsingHistoryView", "Historial de todos los navegadores", "History of all browsers", N + "browsinghistoryview-x64.zip", "dl"));
            t.Add(new Tool("NirSoft", "TurnedOnTimesView", "Horas de encendido/apagado del PC", "PC power on/off times", N + "turnedontimesview.zip", "dl"));
            t.Add(new Tool("NirSoft", "RecentFilesView", "Archivos abiertos recientemente", "Recently opened files", N + "recentfilesview.zip", "dl"));
            t.Add(new Tool("NirSoft", "LoadedDllsView", "DLLs cargadas en cada proceso", "DLLs loaded in each process", N + "loadeddllsview-x64.zip", "dl"));

            // ---------- Eric Zimmerman (net9) ----------
            // CLI tools carry ready-made commands; "{out}" becomes Downloads\SSTool\Resultados\<tool>_<date>.
            t.Add(new Tool("EricZimmerman", "AmcacheParser", "Parsea Amcache.hve", "Parse Amcache.hve", EZ + "AmcacheParser.zip", "dl")
                .Cmd("Analizar el Amcache de este PC → CSV", "Parse this PC's Amcache → CSV",
                     "-f \"C:\\Windows\\appcompat\\Programs\\Amcache.hve\" -i --csv \"{out}\""));
            t.Add(new Tool("EricZimmerman", "bstrings", "Extractor de strings", "String extractor", EZ + "bstrings.zip", "dl")
                .Cmd("Buscar un texto dentro de un archivo (cambia la ruta y el texto)", "Search a text inside a file (change the path and text)",
                     "-f \"C:\\ruta\\al\\archivo\" --ls \"texto\" -o \"{out}\\strings.txt\"")
                .Cmd("Buscar un texto en todos los archivos de una carpeta (cambia la ruta y el texto)", "Search a text in every file of a folder (change the path and text)",
                     "-d \"C:\\ruta\\a\\la\\carpeta\" --ls \"texto\" -o \"{out}\\strings.txt\""));
            t.Add(new Tool("EricZimmerman", "EvtxECmd", "Parser de registros de eventos", "Event log parser", EZ + "EvtxECmd.zip", "dl")
                .Cmd("Log de Seguridad (inicios de sesión, borrado de logs…) → CSV", "Security log (logons, log clearing…) → CSV",
                     "-f \"C:\\Windows\\System32\\winevt\\Logs\\Security.evtx\" --csv \"{out}\"")
                .Cmd("Log de PowerShell → CSV", "PowerShell log → CSV",
                     "-f \"C:\\Windows\\System32\\winevt\\Logs\\Microsoft-Windows-PowerShell%4Operational.evtx\" --csv \"{out}\"")
                .Cmd("Log de Sistema (servicios, apagados…) → CSV", "System log (services, shutdowns…) → CSV",
                     "-f \"C:\\Windows\\System32\\winevt\\Logs\\System.evtx\" --csv \"{out}\"")
                .Cmd("Todos los logs del PC → CSV (tarda bastante)", "Every log on the PC → CSV (takes a while)",
                     "-d \"C:\\Windows\\System32\\winevt\\Logs\" --csv \"{out}\""));
            t.Add(new Tool("EricZimmerman", "JumpListExplorer", "Explorador de Jump Lists (GUI)", "Jump List explorer (GUI)", EZ + "JumpListExplorer.zip", "dl"));
            t.Add(new Tool("EricZimmerman", "MFTECmd", "Parser del MFT", "MFT parser", EZ + "MFTECmd.zip", "dl")
                .Cmd("$MFT del disco C: (todos los archivos, también borrados) → CSV", "C: drive $MFT (every file, deleted ones too) → CSV",
                     "-f \"C:\\$MFT\" --csv \"{out}\"")
                .Cmd("USN Journal ($J) del disco C: con rutas completas → CSV", "C: drive USN Journal ($J) with full paths → CSV",
                     "-f \"C:\\$Extend\\$UsnJrnl:$J\" -m \"C:\\$MFT\" --csv \"{out}\""));
            t.Add(new Tool("EricZimmerman", "PECmd", "Parser de Prefetch", "Prefetch parser", EZ + "PECmd.zip", "dl")
                .Cmd("Analizar todo el Prefetch → CSV", "Parse the whole Prefetch folder → CSV",
                     "-d \"C:\\Windows\\Prefetch\" --csv \"{out}\" -q")
                .Cmd("Analizar todo el Prefetch y verlo en la consola", "Parse the whole Prefetch folder and show it in the console",
                     "-d \"C:\\Windows\\Prefetch\""));
            t.Add(new Tool("EricZimmerman", "RegistryExplorer", "Visor del registro (GUI)", "Registry viewer (GUI)", EZ + "RegistryExplorer.zip", "dl"));
            t.Add(new Tool("EricZimmerman", "ShellBagsExplorer", "Visor de ShellBags (GUI)", "ShellBags viewer (GUI)", EZ + "ShellBagsExplorer.zip", "dl"));
            t.Add(new Tool("EricZimmerman", "SrumECmd", "Parser de SRUM", "SRUM parser", EZ + "SrumECmd.zip", "dl")
                .Cmd("Uso de red y apps (SRUM) de este PC → CSV", "This PC's app and network usage (SRUM) → CSV",
                     "-f \"C:\\Windows\\System32\\sru\\SRUDB.dat\" -r \"C:\\Windows\\System32\\config\\SOFTWARE\" --csv \"{out}\""));
            t.Add(new Tool("EricZimmerman", "TimelineExplorer", "Visor de timelines CSV (GUI)", "CSV timeline viewer (GUI)", EZ + "TimelineExplorer.zip", "dl"));

            // ---------- Others ----------
            t.Add(new Tool("Others", "Jarabel", "Localiza archivos .jar y los analiza", "Finds .jar files and analyzes them", gh("nay-cat", "Jarabel", "light", "Jarabel.Light.exe"), "dl"));
            t.Add(new Tool("Others", "JD-GUI", "Decompilador de Java: abre .jar y .class (necesita Java)", "Java decompiler: opens .jar and .class (needs Java)", gh("java-decompiler", "jd-gui", "v1.6.6", "jd-gui-windows-1.6.6.zip"), "dl"));
            t.Add(new Tool("Others", "VMAware", "Detección avanzada de máquina virtual", "Advanced virtual machine detection", gh("NotRequiem", "VMAware", "v2.8.2", "vmaware.exe"), "dl"));
            t.Add(new Tool("Others", "Hayabusa", "Threat hunting sobre event logs", "Threat hunting over event logs", gh("Yamato-Security", "hayabusa", "v4.2.0", "hayabusa-4.2.0-win-x64.zip"), "dl")
                .Cmd("Timeline de alertas de los logs de este PC → CSV + informe HTML", "Alert timeline from this PC's logs → CSV + HTML report",
                     "dfir-timeline -l -w -C -o \"{out}\\timeline.csv\" -H \"{out}\\resumen.html\"")
                .Cmd("Resumen de inicios de sesión correctos y fallidos → CSV", "Summary of successful and failed logons → CSV",
                     "logon-summary -l -C -o \"{out}\\logon-summary\""));
            t.Add(new Tool("Others", "Velociraptor", "Agente forense de endpoint", "Endpoint forensics agent", gh("Velocidex", "velociraptor", "v0.6.6-1", "velociraptor-v0.6.6-2-windows-amd64.exe"), "dl")
                .Cmd("Abrir la interfaz web local (se abre en el navegador)", "Open the local web interface (opens in the browser)", "gui"));
            t.Add(new Tool("Others", "NTFS Parser", "Parser de sistema de archivos NTFS (CLI)", "NTFS file system parser (CLI)", gh("Velocidex", "go-ntfs", "v0.2.0", "ntfs-windows-amd64.exe"), "dl")
                .Cmd("Volcar el USN Journal del disco C: a un .txt", "Dump the C: drive USN Journal to a .txt",
                     "usn \\\\.\\C: > \"{out}\\usn.txt\"")
                .Cmd("Listar la raíz del disco C: (incluye archivos ocultos del sistema)", "List the root of C: (includes hidden system files)",
                     "ls \\\\.\\C: /"));
            t.Add(new Tool("Others", "ToolsDownloader++", "Descargador de tools de detect.ac (web)", "detect.ac tools downloader (web)", "https://detect.ac/tools", "web"));
            t.Add(new Tool("Others", "Everything", "Buscador instantáneo de archivos", "Instant file search", "https://www.voidtools.com/Everything-1.4.1.1028.x64.zip", "dl"));
            t.Add(new Tool("Others", "HxD", "Editor hexadecimal (instalador)", "Hex editor (installer)", "https://mh-nexus.de/downloads/HxDSetup.zip", "dl"));

            // ---------- Dependencies (installers) ----------
            t.Add(new Tool("Dependencies", ".NET 9 Desktop Runtime", "Runtime de .NET 9 (tools EZ y otras)", ".NET 9 runtime (EZ tools and others)", "https://aka.ms/dotnet/9.0/windowsdesktop-runtime-win-x64.exe", "dl"));
            t.Add(new Tool("Dependencies", ".NET 10 Desktop Runtime", "Runtime de .NET 10", ".NET 10 runtime", "https://aka.ms/dotnet/10.0/windowsdesktop-runtime-win-x64.exe", "dl"));
            t.Add(new Tool("Dependencies", "VC++ Redistributable", "Visual C++ redistributable x64", "Visual C++ redistributable x64", "https://aka.ms/vs/17/release/vc_redist.x64.exe", "dl"));

            // ---------- Webs (abrir página) ----------
            t.Add(new Tool("Webs", "Everything", "Abrir web de Everything", "Open the Everything website", "https://www.voidtools.com/", "web"));
            t.Add(new Tool("Webs", "Eric Zimmerman", "Abrir página de tools de Eric Zimmerman", "Open Eric Zimmerman's tools page", "https://ericzimmerman.github.io/", "web"));
            t.Add(new Tool("Webs", "FTK Imager", "Abrir descarga de FTK Imager", "Open the FTK Imager download", "https://accessdata-ftk-imager.software.informer.com/download/", "web"));
            t.Add(new Tool("Webs", "Detect It Easy", "Abrir releases de DIE", "Open DIE releases", "https://github.com/horsicq/DIE-engine/releases", "web"));
            t.Add(new Tool("Webs", "JDec", "Decompilador de Java online: sube un .jar o .class", "Online Java decompiler: upload a .jar or .class", "https://jdec.app/", "web"));
            t.Add(new Tool("Webs", "NTFS Log Tracker", "Abrir página de NTFS Log Tracker", "Open the NTFS Log Tracker page", "https://sites.google.com/site/forensicnote/ntfs-log-tracker", "web"));
            t.Add(new Tool("Webs", "NirSoft", "Abrir índice de utilidades NirSoft", "Open the NirSoft utilities index", "https://www.nirsoft.net/utils/index.html", "web"));
            t.Add(new Tool("Webs", "System Informer", "Abrir web de System Informer", "Open the System Informer website", "https://systeminformer.sourceforge.io/", "web"));

            // Eric Zimmerman tools are built for .NET 9: the GUI ones (no ready-made commands)
            // need the Windows Desktop runtime, the console ones the base runtime.
            foreach (var tool in t.Where(x => x.Section == "EricZimmerman"))
                tool.Requires = tool.Presets.Count > 0 ? "net9" : "net9desktop";

            return t;
        }
    }
}
