﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shell;
using System.Windows.Threading;
using Ellipse = System.Windows.Shapes.Ellipse;

// SSTool - launcher for screenshare utilities. Each tool is downloaded to a
// temp folder, run, and wiped when it closes (and when SSTool exits).
namespace SSTool
{
    // Kind: "dl" = download+run (temp, wiped on close); "web" = open URL; "ps" = run remote PowerShell script;
    // "local" = PowerShell script bundled inside SSTool.exe (Url = resource name).
    class Tool
    {
        public string Section;
        public string Name;
        public string DescEs;
        public string DescEn;
        public string Url;
        public string Kind;
        // GitHub info parsed from Url (null when the tool is not on GitHub).
        public string Owner, Repo, Tag, Asset;
        // Filled by Updates when a newer release exists; LatestUrl is null if no matching asset was found.
        public string LatestTag, LatestUrl;

        static readonly Regex GhRelease = new Regex(@"^https://github\.com/([^/]+)/([^/]+)/releases/download/([^/]+)/([^/]+)$");
        static readonly Regex GhRaw = new Regex(@"^https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/");

        public Tool(string section, string name, string descEs, string descEn, string url, string kind)
        {
            Section = section; Name = name; DescEs = descEs; DescEn = descEn; Url = url; Kind = kind;
            var m = GhRelease.Match(url);
            if (m.Success)
            {
                Owner = m.Groups[1].Value; Repo = m.Groups[2].Value;
                Tag = Uri.UnescapeDataString(m.Groups[3].Value); Asset = Uri.UnescapeDataString(m.Groups[4].Value);
                return;
            }
            m = GhRaw.Match(url);
            if (m.Success) { Owner = m.Groups[1].Value; Repo = m.Groups[2].Value; }
        }

        // Ready-made command lines for CLI tools ("{out}" = results folder). Empty for GUI tools.
        public readonly List<Preset> Presets = new List<Preset>();

        public Tool Cmd(string es, string en, string args)
        {
            Presets.Add(new Preset { Es = es, En = en, Args = args });
            return this;
        }

        // Bundled scripts: where the latest version is published (the bundled copy is the fallback).
        public string RemoteUrl;
        public Tool From(string url) { RemoteUrl = url; return this; }

        // Short warning shown on the card (scripts that change system settings or leave files behind).
        public string WarnEs, WarnEn;
        public Tool Warn(string es, string en) { WarnEs = es; WarnEn = en; return this; }
        public string Warning { get { return WarnEs == null ? null : (L.Es ? WarnEs : WarnEn); } }

        // Runtime the tool needs to start ("net9" or "net9desktop"); null = nothing special.
        public string Requires;

        public string Desc { get { return L.Es ? DescEs : DescEn; } }
        public bool HasUpdate { get { return LatestTag != null; } }
        // What actually gets downloaded: the newest release when one was found.
        public string RunUrl { get { return LatestUrl ?? Url; } }
        public string RepoUrl { get { return Owner == null ? null : "https://github.com/" + Owner + "/" + Repo; } }
    }

    class Preset
    {
        public string Es, En, Args;
        public string Label { get { return L.Es ? Es : En; } }
    }

    // User preferences, stored in %AppData%\SSTool\settings.ini.
    static class Settings
    {
        public static readonly string Dir =
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SSTool");
        static string FilePath { get { return Path.Combine(Dir, "settings.ini"); } }

        public static string Lang = "es";
        public static bool Reduced;
        public static bool Tooltips = true;

        public static void Load()
        {
            Lang = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName == "es" ? "es" : "en";
            // Weak GPUs (no full hardware rendering) start with reduced animations.
            Reduced = (RenderCapability.Tier >> 16) < 2;
            try
            {
                if (!File.Exists(FilePath)) return;
                foreach (var line in File.ReadAllLines(FilePath))
                {
                    int i = line.IndexOf('=');
                    if (i < 0) continue;
                    string k = line.Substring(0, i).Trim(), v = line.Substring(i + 1).Trim();
                    if (k == "lang") Lang = v == "en" ? "en" : "es";
                    else if (k == "reduced") Reduced = v == "1";
                    else if (k == "tooltips") Tooltips = v == "1";
                }
            }
            catch { }
        }

        public static void Save()
        {
            try
            {
                Directory.CreateDirectory(Dir);
                File.WriteAllLines(FilePath, new[] {
                    "lang=" + Lang, "reduced=" + (Reduced ? "1" : "0"), "tooltips=" + (Tooltips ? "1" : "0") });
            }
            catch { }
        }
    }

    // UI strings: [0] = español, [1] = English.
    static class L
    {
        static readonly Dictionary<string, string[]> S = new Dictionary<string, string[]>
        {
            { "by", new[] { "hecho por Scaan", "made by Scaan" } },
            { "tools_count", new[] { "{0} herramientas", "{0} tools" } },
            { "results_all", new[] { "{0} resultados en todas las secciones", "{0} results across all sections" } },
            { "search_results", new[] { "Resultados", "Results" } },
            { "download_menu", new[] { "Descargar  ▾", "Download  ▾" } },
            { "empty_section", new[] { "Esta sección aún no tiene herramientas.", "This section has no tools yet." } },
            { "no_results", new[] { "Sin resultados para \"{0}\".", "No results for \"{0}\"." } },
            { "search_ph", new[] { "Buscar en todas las herramientas…   Enter abre la primera", "Search all tools…   Enter opens the first" } },
            { "pill_open", new[] { "Abrir  ↗", "Open  ↗" } },
            { "pill_run", new[] { "Ejecutar  ▶", "Run  ▶" } },
            { "pill_dl", new[] { "Descargar  ↓", "Download  ↓" } },
            { "downloading", new[] { "Descargando…", "Downloading…" } },
            { "opening", new[] { "Abriendo…", "Opening…" } },
            { "choose_tools", new[] { "Elegir herramientas", "Choose tools" } },
            { "select_all", new[] { "Seleccionar todo", "Select all" } },
            { "cancel", new[] { "Cancelar", "Cancel" } },
            { "download", new[] { "Descargar", "Download" } },
            { "saved_many", new[] { "{0} herramientas guardadas en Descargas\\SSTool", "{0} tools saved to Downloads\\SSTool" } },
            { "saved_one", new[] { "{0} guardada en Descargas\\SSTool\\{1}", "{0} saved to Downloads\\SSTool\\{1}" } },
            { "failed", new[] { "Fallaron: {0}", "Failed: {0}" } },
            { "open_folder", new[] { "Abrir carpeta", "Open folder" } },
            { "err_open", new[] { "No se pudo abrir {0}: {1}", "Couldn't open {0}: {1}" } },
            { "no_exe", new[] { "No se encontró ningún .exe dentro del zip.", "No .exe found inside the zip." } },
            { "running", new[] { "En ejecución", "Running" } },
            { "tool_closed", new[] { "{0} cerrada", "{0} closed" } },
            { "close_tool", new[] { "Cerrar {0}", "Close {0}" } },
            { "ctx_version", new[] { "Versión: {0}", "Version: {0}" } },
            { "ctx_update", new[] { "Nueva versión disponible: {0}", "New version available: {0}" } },
            { "ctx_repo", new[] { "Abrir en GitHub", "Open on GitHub" } },
            { "ctx_copy", new[] { "Copiar enlace", "Copy link" } },
            { "ctx_save", new[] { "Guardar en Descargas", "Save to Downloads" } },
            { "ctx_script", new[] { "Ver código del script", "View script source" } },
            { "ctx_open", new[] { "Abrir web", "Open website" } },
            { "ctx_run", new[] { "Ejecutar script", "Run script" } },
            { "ctx_dl", new[] { "Descargar y abrir", "Download and open" } },
            { "copied", new[] { "Enlace copiado", "Link copied" } },
            { "updates_found", new[] { "Hay {0} herramientas con versión nueva (marcadas en verde)", "{0} tools have a new version (marked in green)" } },
            { "checking", new[] { "Buscando actualizaciones…", "Checking for updates…" } },
            { "up_to_date", new[] { "Todas las herramientas están al día", "All tools are up to date" } },
            { "update_limit", new[] { "GitHub limitó las consultas; prueba de nuevo en un rato", "GitHub rate-limited the check; try again later" } },
            { "settings", new[] { "Ajustes", "Settings" } },
            { "language", new[] { "Idioma", "Language" } },
            { "animations", new[] { "Animaciones", "Animations" } },
            { "anim_full", new[] { "Completas", "Full" } },
            { "anim_reduced", new[] { "Reducidas", "Reduced" } },
            { "tooltips", new[] { "Tooltips", "Tooltips" } },
            { "yes", new[] { "Sí", "Yes" } },
            { "no", new[] { "No", "No" } },
            { "updates", new[] { "Actualizaciones", "Updates" } },
            { "check_updates", new[] { "Buscar ahora", "Check now" } },
            { "shortcuts", new[] { "Atajos", "Shortcuts" } },
            { "shortcuts_text", new[] {
                "Ctrl+F  buscar en todo\nEnter  abrir el primer resultado\nEsc  cerrar búsqueda / ventana\nCtrl+1…9  cambiar de sección\nClic derecho en una tool  más opciones",
                "Ctrl+F  search everything\nEnter  open the first result\nEsc  close search / dialog\nCtrl+1…9  switch section\nRight-click a tool  more options" } },
            { "close", new[] { "Cerrar", "Close" } },
            { "tip_dl", new[] { "Se descarga a una carpeta temporal y se borra al cerrarla.", "Downloaded to a temp folder and wiped when closed." } },
            { "tip_ps", new[] { "Script de PowerShell: se ejecuta en memoria, no guarda nada.", "PowerShell script: runs in memory, saves nothing." } },
            { "tip_web", new[] { "Abre la página en tu navegador.", "Opens the page in your browser." } },
            { "tip_local", new[] { "Script incluido en SSTool: se abre en una ventana de PowerShell y se borra al cerrarla.", "Script bundled with SSTool: opens in a PowerShell window and is wiped when closed." } },
            { "src_local", new[] { "incluido en SSTool", "bundled with SSTool" } },
            { "tip_source", new[] { "Fuente: {0}", "Source: {0}" } },
            { "tip_size", new[] { "Tamaño: {0}", "Size: {0}" } },
            { "size_checking", new[] { "calculando…", "checking…" } },
            { "size_unknown", new[] { "desconocido", "unknown" } },
            { "total", new[] { "Total:", "Total:" } },
            { "runtime_missing", new[] { "Falta .NET 9", "Needs .NET 9" } },
            { "runtime_tip", new[] { "Necesita .NET 9 y no está instalado en este PC (instálalo desde Dependencias).", "Needs .NET 9, which isn't installed on this PC (install it from Dependencies)." } },
            { "runtime_toast", new[] { "{0} necesita .NET 9 y no está instalado: puede que no abra.", "{0} needs .NET 9, which isn't installed: it may not open." } },
            { "runtime_go", new[] { "Ir a Dependencias", "Go to Dependencies" } },
            { "self_version", new[] { "Versión", "Version" } },
            { "self_available", new[] { "SSTool {0} disponible (tienes {1})", "SSTool {0} is available (you have {1})" } },
            { "self_update", new[] { "Actualizar ahora", "Update now" } },
            { "self_update_to", new[] { "Actualizar a {0}", "Update to {0}" } },
            { "self_downloading", new[] { "Descargando SSTool {0}…", "Downloading SSTool {0}…" } },
            { "self_failed", new[] { "No se pudo actualizar SSTool: {0}", "Couldn't update SSTool: {0}" } },
            { "self_latest", new[] { "al día", "up to date" } },
            { "tip_right", new[] { "Clic derecho: más opciones", "Right-click: more options" } },
            { "tip_cmd", new[] { "Herramienta de consola: al abrirla eliges qué comando ejecutar.", "Console tool: when opened you choose which command to run." } },
            { "cmd_title", new[] { "Ejecutar {0}", "Run {0}" } },
            { "cmd_pick", new[] { "Elige qué hacer", "Choose what to do" } },
            { "cmd_line", new[] { "Comando (puedes editarlo)", "Command (you can edit it)" } },
            { "cmd_out", new[] { "Los resultados se guardan en Descargas\\SSTool\\Resultados y la carpeta se abre al terminar.", "Results are saved to Downloads\\SSTool\\Resultados and the folder opens when done." } },
            { "cmd_run", new[] { "Ejecutar", "Run" } },
            { "cmd_console", new[] { "Solo abrir consola", "Just open console" } },
            { "cmd_done", new[] { "Resultados guardados en:", "Results saved to:" } },
            { "kind_dl", new[] { "Ejecutable", "Executable" } },
            { "kind_cli", new[] { "Herramienta de consola", "Console tool" } },
            { "kind_ps", new[] { "Script de PowerShell", "PowerShell script" } },
            { "kind_local", new[] { "Script incluido", "Bundled script" } },
            { "kind_web", new[] { "Sitio web", "Website" } },
            { "no_results_hint", new[] { "Prueba con otra palabra o pulsa Esc para volver.", "Try another word or press Esc to go back." } },
        };

        public static bool Es { get { return Settings.Lang != "en"; } }

        public static string T(string key)
        {
            string[] v;
            return S.TryGetValue(key, out v) ? v[Es ? 0 : 1] : key;
        }

        public static string F(string key, params object[] args) { return string.Format(T(key), args); }

        public static string Section(string s)
        {
            switch (s)
            {
                case "Others": return Es ? "Otros" : "Others";
                case "Dependencies": return Es ? "Dependencias" : "Dependencies";
            }
            return s;
        }
    }

    static class Theme
    {
        public static Color Hex(string h)
        {
            return (Color)ColorConverter.ConvertFromString(h);
        }
        public static readonly FontFamily Icons = new FontFamily("Segoe MDL2 Assets");
        public static readonly Brush Bg      = new SolidColorBrush(Hex("#070b14"));
        public static readonly Brush Bar     = new SolidColorBrush(Hex("#B30a0f1e"));
        public static readonly Brush Card     = new SolidColorBrush(Hex("#121a2b"));
        public static readonly Brush CardHov  = new SolidColorBrush(Hex("#18233a"));
        public static readonly Brush Ink      = new SolidColorBrush(Hex("#eaf0fb"));
        public static readonly Brush Mut      = new SolidColorBrush(Hex("#818ea6"));
        public static readonly Brush Dim      = new SolidColorBrush(Hex("#5b6780"));
        public static readonly FontFamily Mono = new FontFamily("Cascadia Mono, Consolas");
        // One accent for the whole app (blue, fading into violet on the logo).
        public static readonly Brush Acc      = new SolidColorBrush(Hex("#3b82f6"));
        public static readonly Brush Acc2     = new SolidColorBrush(Hex("#6ba5ff"));
        public static readonly Color Glow     = Hex("#3b82f6");
        public static readonly Color Glow2    = Hex("#8b5cf6");
        public static readonly Brush Line     = new SolidColorBrush(Color.FromArgb(26, 255, 255, 255));
        public static readonly Brush Panel    = new SolidColorBrush(Hex("#F20d1424"));
        public static readonly Color Ok       = Hex("#34d399");
        public static readonly Color Bad      = Hex("#f43f5e");
        public static readonly Color Warn     = Hex("#fbbf24");

        // Every section uses the same accent.
        public static Color SectionColor(string s) { return Glow; }

        // Deep space background.
        public static Brush SpaceBg()
        {
            var g = new LinearGradientBrush();
            g.StartPoint = new Point(0, 0); g.EndPoint = new Point(1, 1);
            g.GradientStops.Add(new GradientStop(Hex("#0a0f20"), 0));
            g.GradientStops.Add(new GradientStop(Hex("#05070f"), 0.5));
            g.GradientStops.Add(new GradientStop(Hex("#0a0818"), 1));
            g.Freeze(); return g;
        }

        // Logo tile: the accent blue fading into violet.
        public static Brush LogoBg()
        {
            var g = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(1, 1) };
            g.GradientStops.Add(new GradientStop(Glow, 0));
            g.GradientStops.Add(new GradientStop(Glow2, 1));
            g.Freeze(); return g;
        }

        // Card background: translucent glass so the starfield shows through.
        public static Brush CardBg()
        {
            var g = new LinearGradientBrush();
            g.StartPoint = new Point(0, 0); g.EndPoint = new Point(0, 1);
            g.GradientStops.Add(new GradientStop(Hex("#C81b2740"), 0));
            g.GradientStops.Add(new GradientStop(Hex("#C8101a2e"), 1));
            g.Freeze(); return g;
        }
        public static Brush CardBgHov()
        {
            var g = new LinearGradientBrush();
            g.StartPoint = new Point(0, 0); g.EndPoint = new Point(0, 1);
            g.GradientStops.Add(new GradientStop(Hex("#E024355a"), 0));
            g.GradientStops.Add(new GradientStop(Hex("#E014223a"), 1));
            g.Freeze(); return g;
        }

        static Theme()
        {
            Bg.Freeze(); Bar.Freeze(); Card.Freeze(); CardHov.Freeze(); Ink.Freeze();
            Mut.Freeze(); Dim.Freeze(); Acc.Freeze(); Acc2.Freeze(); Line.Freeze(); Panel.Freeze();
        }
    }

    // The SSTool logo: a glowing hexagon (cyan -> blue -> violet) with a glass shine, an inner
    // outline and a slanted "SS". Animated: a light sweep crosses it every few seconds, and
    // withRing adds a spinning ring of light around it (splash screen).
    static class Logo
    {
        static Geometry Hex(double size, double scale)
        {
            double c = size / 2, r = size / 2 * scale;
            var g = new StreamGeometry();
            using (var ctx = g.Open())
            {
                for (int i = 0; i < 6; i++)
                {
                    double a = Math.PI / 180 * (60 * i - 90);
                    var p = new Point(c + r * Math.Cos(a), c + r * Math.Sin(a));
                    if (i == 0) ctx.BeginFigure(p, true, true); else ctx.LineTo(p, true, true);
                }
            }
            g.Freeze();
            return g;
        }

        public static FrameworkElement Create(double size, bool animated, bool withRing = false)
        {
            var host = new Grid { Width = size, Height = size };

            var fill = new LinearGradientBrush { StartPoint = new Point(0.1, 0), EndPoint = new Point(0.9, 1) };
            fill.GradientStops.Add(new GradientStop(Theme.Hex("#22d3ee"), 0));
            fill.GradientStops.Add(new GradientStop(Theme.Hex("#3b82f6"), 0.45));
            fill.GradientStops.Add(new GradientStop(Theme.Hex("#8b5cf6"), 1));
            fill.Freeze();

            // Body: the stroke in the same gradient rounds the corners.
            var glow = new DropShadowEffect { Color = Theme.Glow, ShadowDepth = 0, BlurRadius = size * 0.35, Opacity = 0.75 };
            host.Children.Add(new System.Windows.Shapes.Path
            {
                Data = Hex(size, 0.86), Fill = fill, Stroke = fill, StrokeThickness = size * 0.09,
                StrokeLineJoin = PenLineJoin.Round, Effect = glow
            });

            // Glass shine on the upper half.
            var shine = new LinearGradientBrush { StartPoint = new Point(0.5, 0), EndPoint = new Point(0.5, 0.6) };
            shine.GradientStops.Add(new GradientStop(Color.FromArgb(90, 255, 255, 255), 0));
            shine.GradientStops.Add(new GradientStop(Color.FromArgb(0, 255, 255, 255), 1));
            host.Children.Add(new System.Windows.Shapes.Path { Data = Hex(size, 0.86), Fill = shine, IsHitTestVisible = false });

            // Thin inner outline for depth.
            host.Children.Add(new System.Windows.Shapes.Path
            {
                Data = Hex(size, 0.66), Stroke = new SolidColorBrush(Color.FromArgb(80, 255, 255, 255)),
                StrokeThickness = Math.Max(0.8, size * 0.025), StrokeLineJoin = PenLineJoin.Round
            });

            // Slanted monogram.
            host.Children.Add(new TextBlock
            {
                Text = "SS", Foreground = Brushes.White, FontSize = size * 0.36, FontWeight = FontWeights.Black, FontStyle = FontStyles.Italic,
                HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, size * 0.02, size * 0.03),
                Effect = new DropShadowEffect { Color = Theme.Hex("#1e1b4b"), ShadowDepth = size * 0.03, Direction = 270, BlurRadius = size * 0.08, Opacity = 0.7 }
            });

            if (!animated) return host;

            // Breathing glow.
            glow.BeginAnimation(DropShadowEffect.BlurRadiusProperty, new DoubleAnimation(size * 0.2, size * 0.5, new Duration(TimeSpan.FromSeconds(2.2)))
            { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut } });

            // Light sweep: a slanted bright band crossing the hexagon every few seconds, clipped to it.
            var sweepMove = new TranslateTransform(-size * 0.6, 0);
            var sweepTg = new TransformGroup();
            sweepTg.Children.Add(new SkewTransform(-25, 0));
            sweepTg.Children.Add(sweepMove);
            var sweepBrush = new LinearGradientBrush { StartPoint = new Point(0, 0.5), EndPoint = new Point(1, 0.5) };
            sweepBrush.GradientStops.Add(new GradientStop(Color.FromArgb(0, 255, 255, 255), 0));
            sweepBrush.GradientStops.Add(new GradientStop(Color.FromArgb(150, 255, 255, 255), 0.5));
            sweepBrush.GradientStops.Add(new GradientStop(Color.FromArgb(0, 255, 255, 255), 1));
            var sweep = new System.Windows.Shapes.Rectangle { Width = size * 0.35, Height = size * 1.4, Fill = sweepBrush, RenderTransform = sweepTg, IsHitTestVisible = false };
            var sweepLayer = new Canvas { Width = size, Height = size, Clip = Hex(size, 0.95), IsHitTestVisible = false };
            Canvas.SetTop(sweep, -size * 0.2);
            sweepLayer.Children.Add(sweep);
            host.Children.Add(sweepLayer);
            var sweepAnim = new DoubleAnimationUsingKeyFrames { RepeatBehavior = RepeatBehavior.Forever, Duration = new Duration(TimeSpan.FromSeconds(4.5)) };
            sweepAnim.KeyFrames.Add(new DiscreteDoubleKeyFrame(-size * 0.6, KeyTime.FromTimeSpan(TimeSpan.Zero)));
            sweepAnim.KeyFrames.Add(new DiscreteDoubleKeyFrame(-size * 0.6, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(3.4))));
            sweepAnim.KeyFrames.Add(new EasingDoubleKeyFrame(size * 1.4, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(4.3)), new CubicEase { EasingMode = EasingMode.EaseInOut }));
            sweepMove.BeginAnimation(TranslateTransform.XProperty, sweepAnim);

            if (withRing)
            {
                // A ring of light (bright arc fading to nothing) spinning around the logo.
                double d = size * 1.35;
                var ringBrush = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(1, 1) };
                ringBrush.GradientStops.Add(new GradientStop(Color.FromArgb(0, 34, 211, 238), 0));
                ringBrush.GradientStops.Add(new GradientStop(Theme.Hex("#22d3ee"), 0.5));
                ringBrush.GradientStops.Add(new GradientStop(Theme.Hex("#8b5cf6"), 0.75));
                ringBrush.GradientStops.Add(new GradientStop(Color.FromArgb(0, 139, 92, 246), 1));
                var spin = new RotateTransform(0);
                var ring = new Ellipse
                {
                    Width = d, Height = d, Stroke = ringBrush, StrokeThickness = Math.Max(1.5, size * 0.035),
                    RenderTransformOrigin = new Point(0.5, 0.5), RenderTransform = spin, IsHitTestVisible = false,
                    Effect = new DropShadowEffect { Color = Theme.Hex("#22d3ee"), ShadowDepth = 0, BlurRadius = 10, Opacity = 0.8 }
                };
                var ringHost = new Canvas { Width = size, Height = size, IsHitTestVisible = false };
                Canvas.SetLeft(ring, (size - d) / 2); Canvas.SetTop(ring, (size - d) / 2);
                ringHost.Children.Add(ring);
                host.Children.Insert(0, ringHost);
                spin.BeginAnimation(RotateTransform.AngleProperty, new DoubleAnimation(0, 360, new Duration(TimeSpan.FromSeconds(1.6))) { RepeatBehavior = RepeatBehavior.Forever });
            }
            return host;
        }
    }

    // A tool SSTool launched and is still running.
    class Running
    {
        public Tool Tool;
        public Process Proc;
        public string Dir;   // temp folder to wipe when it exits (null for scripts)
    }

    static class Engine
    {
        // Temp folder scoped by process id, so a second SSTool instance never
        // wipes the tools this one is running.
        public static readonly string TempRoot =
            Path.Combine(Path.GetTempPath(), "SSTool", Process.GetCurrentProcess().Id.ToString());
        public static readonly string DownloadsRoot =
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "SSTool");

        // Temp folders + the tools we launched, so we can wipe/close them on exit.
        static readonly List<string> _dirs = new List<string>();
        static readonly List<Running> _running = new List<Running>();
        static readonly object _gate = new object();

        // Raised (on a background thread) when a tool starts or exits.
        public static event Action Changed;

        static Engine()
        {
            // Our folder is named by PID; clear it in case the PID was reused.
            try { if (Directory.Exists(TempRoot)) Directory.Delete(TempRoot, true); }
            catch { }
        }

        public static List<Running> RunningTools()
        {
            lock (_gate) { return _running.ToList(); }
        }

        static void Notify()
        {
            var h = Changed;
            if (h != null) h();
        }

        static void Track(Tool t, Process p, string dir)
        {
            var r = new Running { Tool = t, Proc = p, Dir = dir };
            lock (_gate) { _running.Add(r); }
            Watch(r, p);
            Notify();
        }

        static void Watch(Running r, Process p)
        {
            p.EnableRaisingEvents = true;
            p.Exited += delegate
            {
                // Launchers (JD-GUI starts javaw, installers start their setup...) quit right after
                // starting the real program: keep following that one instead of wiping its folder.
                Process child = LiveChildOf(p.Id);
                if (child != null)
                {
                    lock (_gate) { r.Proc = child; }
                    Watch(r, child);
                    return;
                }
                lock (_gate) { _running.Remove(r); }
                if (r.Dir != null) Wipe(r.Dir);
                Notify();
            };
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct PROCESSENTRY32
        {
            public uint dwSize, cntUsage, th32ProcessID;
            public IntPtr th32DefaultHeapID;
            public uint th32ModuleID, cntThreads, th32ParentProcessID;
            public int pcPriClassBase;
            public uint dwFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string szExeFile;
        }
        [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr CreateToolhelp32Snapshot(uint flags, uint pid);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool Process32FirstW(IntPtr snap, ref PROCESSENTRY32 e);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool Process32NextW(IntPtr snap, ref PROCESSENTRY32 e);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);

        // A still-running process started by pid, or null.
        static Process LiveChildOf(int pid)
        {
            IntPtr snap = CreateToolhelp32Snapshot(2, 0);   // TH32CS_SNAPPROCESS
            if (snap == new IntPtr(-1)) return null;
            try
            {
                var e = new PROCESSENTRY32 { dwSize = (uint)Marshal.SizeOf(typeof(PROCESSENTRY32)) };
                for (bool ok = Process32FirstW(snap, ref e); ok; ok = Process32NextW(snap, ref e))
                {
                    if (e.th32ParentProcessID != (uint)pid || e.szExeFile.Equals("conhost.exe", StringComparison.OrdinalIgnoreCase)) continue;
                    try
                    {
                        var c = Process.GetProcessById((int)e.th32ProcessID);
                        if (!c.HasExited) return c;
                    }
                    catch { }
                }
            }
            finally { CloseHandle(snap); }
            return null;
        }

        // True when the runtime a tool needs is missing (checks the shared .NET folders, which every
        // .NET installer fills: shared\Microsoft.NETCore.App\9.x, shared\Microsoft.WindowsDesktop.App\9.x).
        public static bool MissingRuntime(Tool t)
        {
            if (t.Requires == null) return false;
            string framework = t.Requires == "net9desktop" ? "Microsoft.WindowsDesktop.App" : "Microsoft.NETCore.App";
            foreach (var root in new[] {
                Environment.GetEnvironmentVariable("DOTNET_ROOT"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet") })
            {
                if (string.IsNullOrEmpty(root)) continue;
                try
                {
                    string dir = Path.Combine(root, "shared", framework);
                    if (Directory.Exists(dir) && Directory.GetDirectories(dir, "9.*").Length > 0) return false;
                }
                catch { }
            }
            return true;
        }

        // File size before downloading: a HEAD request, cached per URL (-1 = the server doesn't say).
        static readonly Dictionary<string, long> _sizes = new Dictionary<string, long>();
        static readonly Dictionary<string, List<Action<long>>> _sizing = new Dictionary<string, List<Action<long>>>();

        public static bool KnownSize(string url, out long size)
        {
            lock (_sizes) return _sizes.TryGetValue(url, out size);
        }

        // Starts the lookup if needed; done(size) runs on a worker thread when it finishes
        // (also when a lookup for the same URL was already running).
        public static void FetchSize(string url, Action<long> done)
        {
            lock (_sizes)
            {
                long known;
                if (_sizes.TryGetValue(url, out known)) { if (done != null) done(known); return; }
                List<Action<long>> waiting;
                if (_sizing.TryGetValue(url, out waiting)) { if (done != null) waiting.Add(done); return; }
                _sizing[url] = new List<Action<long>>();
                if (done != null) _sizing[url].Add(done);
            }
            ThreadPool.QueueUserWorkItem(delegate
            {
                long size = -1;
                try
                {
                    var req = (HttpWebRequest)WebRequest.Create(url);
                    req.Method = "HEAD";
                    req.UserAgent = "Mozilla/5.0 SSTool";
                    req.Timeout = 10000;
                    using (var resp = req.GetResponse()) size = resp.ContentLength;
                }
                catch { }
                List<Action<long>> callbacks;
                lock (_sizes) { _sizes[url] = size; callbacks = _sizing[url]; _sizing.Remove(url); }
                foreach (var cb in callbacks) try { cb(size); } catch { }
            });
        }

        // Streamed download with progress (done, total; total is -1 when the server doesn't say).
        public static void Download(string url, string file, Action<long, long> progress, int timeoutMs = 60000)
        {
            var req = (HttpWebRequest)WebRequest.Create(url);
            req.UserAgent = "Mozilla/5.0 SSTool";
            // Timeouts, so a dead server cannot hang a download forever.
            req.Timeout = timeoutMs;
            req.ReadWriteTimeout = timeoutMs;
            using (var resp = req.GetResponse())
            using (var src = resp.GetResponseStream())
            using (var dst = File.Create(file))
            {
                long total = resp.ContentLength, done = 0;
                var buf = new byte[81920];
                var sw = Stopwatch.StartNew();
                long last = -1000;
                int n;
                while ((n = src.Read(buf, 0, buf.Length)) > 0)
                {
                    dst.Write(buf, 0, n);
                    done += n;
                    if (progress != null && sw.ElapsedMilliseconds - last >= 80)
                    {
                        last = sw.ElapsedMilliseconds;
                        progress(done, total);
                    }
                }
                if (progress != null) progress(done, total);
            }
        }

        // Run a remote script from a cmd window (cmd calls PowerShell to run it).
        // In memory (irm | iex) so nothing hits disk; /k keeps the window open.
        public static void RunPs(Tool t)
        {
            string args = "/k powershell -NoProfile -ExecutionPolicy Bypass -Command \"irm '" + t.Url + "' | iex\"";
            var psi = new ProcessStartInfo("cmd.exe", args);
            psi.UseShellExecute = true;
            var p = Process.Start(psi);
            if (p != null) Track(t, p, null);
        }

        public static readonly string ResultsRoot = Path.Combine(DownloadsRoot, "Resultados");

        // Bundled script: written to temp, run in its own PowerShell window, wiped when that window closes.
        public static void RunLocal(Tool t)
        {
            string dir = Path.Combine(TempRoot, Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            lock (_gate) { _dirs.Add(dir); }
            string file = Path.Combine(dir, t.Url);
            // Latest version from GitHub when there is one; the copy inside SSTool.exe works offline.
            bool fresh = false;
            if (t.RemoteUrl != null)
            {
                try
                {
                    Download(t.RemoteUrl, file, null, 6000);
                    fresh = new FileInfo(file).Length > 1000 && File.ReadAllText(file).Contains("NTFS Artifacts");
                }
                catch { }
            }
            if (!fresh)
            {
                using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream(t.Url))
                {
                    if (s == null) { Wipe(dir); throw new Exception(t.Url + " no está incluido en SSTool.exe"); }
                    using (var f = File.Create(file)) s.CopyTo(f);
                }
            }
            var psi = new ProcessStartInfo("powershell.exe", "-NoExit -NoProfile -ExecutionPolicy Bypass -File \"" + file + "\"");
            psi.UseShellExecute = true;
            psi.WorkingDirectory = dir;
            var p = Process.Start(psi);
            if (p != null) Track(t, p, dir);
            else Wipe(dir);
        }

        // Download+extract+run in temp; wipe the folder when the process exits.
        // args: command line for CLI tools (null = run with none); outDir: results folder opened when it finishes.
        public static void RunTemp(Tool t, Action<long, long> progress, string args = null, string outDir = null)
        {
            string dir = Path.Combine(TempRoot, Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            lock (_gate) { _dirs.Add(dir); }

            string url = t.RunUrl;
            bool isZip = url.ToLowerInvariant().EndsWith(".zip");
            bool isGz = url.ToLowerInvariant().EndsWith(".gz");
            string file = Path.Combine(dir, isZip ? "pkg.zip" : SafeName(t.Name) + (isGz ? ".exe.gz" : ".exe"));

            try
            {
                Download(url, file, progress);

                string exe = file;
                if (isGz) exe = Gunzip(file);
                else if (isZip)
                {
                    string ex = Path.Combine(dir, "x");
                    Directory.CreateDirectory(ex);
                    ZipFile.ExtractToDirectory(file, ex);
                    exe = PickExe(ex, t.Name);
                    if (exe == null) throw new Exception(L.T("no_exe"));
                }

                ProcessStartInfo psi;
                if (IsConsoleExe(exe))
                {
                    // CLI tools (PECmd, MFTECmd, Hayabusa...) would print and close at once.
                    // Run them inside cmd /k: the window stays open in the tool's folder,
                    // so the output can be read and the tool re-run with arguments.
                    string title = Regex.Replace(t.Name, "[&|<>^\"%]", "");
                    string line = "title " + title + " & \"" + exe + "\"";
                    if (!string.IsNullOrEmpty(args)) line += " " + args;
                    if (outDir != null)
                        line += " & echo. & echo [SSTool] " + L.T("cmd_done") + " \"" + outDir + "\" & start \"\" \"" + outDir + "\"";
                    // cmd strips the outer quotes of /k "...", leaving the inner ones intact.
                    psi = new ProcessStartInfo("cmd.exe", "/k \"" + line + "\"");
                }
                else psi = new ProcessStartInfo(exe, args ?? "");
                psi.UseShellExecute = true;
                psi.WorkingDirectory = Path.GetDirectoryName(exe);
                var p = Process.Start(psi);
                if (p != null) Track(t, p, dir);
                else Wipe(dir);
            }
            catch
            {
                Wipe(dir);
                throw;
            }
        }

        // Download (and extract) into Downloads\SSTool\<section>. Stays on disk. Returns that folder.
        public static string SaveToDownloads(Tool t, Action<long, long> progress)
        {
            string sectionDir = Path.Combine(DownloadsRoot, t.Section);
            Directory.CreateDirectory(sectionDir);
            string url = t.RunUrl;
            bool isZip = url.ToLowerInvariant().EndsWith(".zip");
            bool isGz = url.ToLowerInvariant().EndsWith(".gz");
            string target = Path.Combine(sectionDir, SafeName(t.Name) + (isZip ? ".zip" : (isGz ? ".exe.gz" : ".exe")));
            try { Download(url, target, progress); }
            catch
            {
                try { File.Delete(target); } catch { }
                throw;
            }
            if (isGz) Gunzip(target);
            else if (isZip)
            {
                string outDir = Path.Combine(sectionDir, SafeName(t.Name));
                if (Directory.Exists(outDir)) Directory.Delete(outDir, true);
                ZipFile.ExtractToDirectory(target, outDir);
                File.Delete(target);
            }
            return sectionDir;
        }

        // "tool.exe.gz" -> "tool.exe" (Velociraptor ships gzipped binaries). Returns the extracted path.
        static string Gunzip(string gz)
        {
            string exe = gz.Substring(0, gz.Length - 3);
            using (var src = File.OpenRead(gz))
            using (var unz = new GZipStream(src, CompressionMode.Decompress))
            using (var dst = File.Create(exe))
                unz.CopyTo(dst);
            File.Delete(gz);
            return exe;
        }

        public static void Open(string url)
        {
            var psi = new ProcessStartInfo(url);
            psi.UseShellExecute = true;
            Process.Start(psi);
        }

        // Close a tool and everything it spawned (cmd -> powershell, launchers -> children).
        public static void Kill(Running r) { KillTree(r.Proc); }

        static void KillTree(Process p)
        {
            try { if (p.HasExited) return; } catch { return; }
            try
            {
                var psi = new ProcessStartInfo("taskkill", "/PID " + p.Id + " /T /F");
                psi.CreateNoWindow = true; psi.UseShellExecute = false;
                using (var k = Process.Start(psi)) k.WaitForExit(3000);
            }
            catch { }
            try { if (!p.HasExited) { p.Kill(); p.WaitForExit(2000); } } catch { }
        }

        // True when the PE header's subsystem is "Windows console" (3).
        internal static bool IsConsoleExe(string path)
        {
            try
            {
                using (var br = new BinaryReader(File.OpenRead(path)))
                {
                    if (br.ReadUInt16() != 0x5A4D) return false;            // "MZ"
                    br.BaseStream.Seek(0x3C, SeekOrigin.Begin);
                    int pe = br.ReadInt32();
                    br.BaseStream.Seek(pe, SeekOrigin.Begin);
                    if (br.ReadUInt32() != 0x00004550) return false;        // "PE\0\0"
                    // Subsystem sits 68 bytes into the optional header (same for PE32 and PE32+),
                    // which follows the 4-byte signature and the 20-byte file header.
                    br.BaseStream.Seek(pe + 24 + 68, SeekOrigin.Begin);
                    return br.ReadUInt16() == 3;
                }
            }
            catch { return false; }
        }

        static string PickExe(string dir, string prefer)
        {
            var exes = Directory.GetFiles(dir, "*.exe", SearchOption.AllDirectories);
            if (exes.Length == 0) return null;
            string want = SafeName(prefer).ToLowerInvariant();
            var hit = exes.FirstOrDefault(
                delegate(string e) { return Path.GetFileNameWithoutExtension(e).ToLowerInvariant() == want; });
            if (hit != null) return hit;
            // Prefer non-"uninstall/setup/vc_redist" exe, biggest one.
            var good = exes.Where(delegate(string e)
            {
                string n = Path.GetFileName(e).ToLowerInvariant();
                return !n.Contains("unins") && !n.Contains("setup") && !n.Contains("redist");
            }).ToArray();
            if (good.Length == 0) good = exes;
            return good.OrderByDescending(delegate(string e) { return new FileInfo(e).Length; }).First();
        }

        static string SafeName(string s)
        {
            foreach (char c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
            return s.Replace(' ', '_');
        }

        static void Wipe(string dir)
        {
            for (int i = 0; i < 6; i++)
            {
                try { if (Directory.Exists(dir)) Directory.Delete(dir, true); lock (_gate) { _dirs.Remove(dir); } return; }
                catch { Thread.Sleep(400); }
            }
        }

        // On exit: close every tool we opened (so its files unlock), then wipe.
        public static void WipeAll()
        {
            Running[] rs; string[] copy;
            lock (_gate) { rs = _running.ToArray(); copy = _dirs.ToArray(); }
            foreach (var r in rs) KillTree(r.Proc);
            foreach (var d in copy) Wipe(d);
            try { if (Directory.Exists(TempRoot)) Directory.Delete(TempRoot, true); } catch { }
        }
    }

    // Asks GitHub for each repo's latest release; results cached for 6 hours.
    static class Updates
    {
        static readonly Regex TagRx = new Regex("\"tag_name\"\\s*:\\s*\"([^\"]+)\"");
        static readonly Regex AssetRx = new Regex("\"browser_download_url\"\\s*:\\s*\"([^\"]+)\"");
        static readonly Regex NumRx = new Regex(@"\d+(\.\d+)*");
        static string CacheFile { get { return Path.Combine(Settings.Dir, "updates.cache"); } }

        public static bool RateLimited;

        // ---------- SSTool itself ----------
        // Bump AppVersion on every release; publish it on GitHub (AppRepo) with tag "vX.Y.Z" and an "SSTool.exe" asset.
        public const string AppVersion = "1.0.0";
        public const string AppRepo = "ScaanSs/SSTool";
        public static string SelfTag, SelfUrl;   // set when a newer SSTool release exists

        static string ExePath { get { return Process.GetCurrentProcess().MainModule.FileName; } }

        // True when the latest GitHub release of SSTool is newer than this build and has an .exe to download.
        public static bool CheckSelf()
        {
            var r = Fetch(AppRepo);
            if (r == null || !IsNewer(r[0], AppVersion)) return false;
            var assets = r.Skip(1).ToList();
            string url = assets.FirstOrDefault(u => string.Equals(FileOf(u), "SSTool.exe", StringComparison.OrdinalIgnoreCase))
                      ?? assets.FirstOrDefault(u => u.EndsWith(".exe", StringComparison.OrdinalIgnoreCase));
            if (url == null) return false;
            SelfTag = r[0]; SelfUrl = url;
            return true;
        }

        // Downloads the new exe next to the running one and swaps them (a running exe can be renamed,
        // not overwritten). The old copy is deleted on the next start by CleanupSelf.
        public static void ApplySelf(Action<long, long> progress)
        {
            string exe = ExePath, fresh = exe + ".new", old = exe + ".old";
            if (File.Exists(fresh)) File.Delete(fresh);
            Engine.Download(SelfUrl, fresh, progress);
            using (var fs = File.OpenRead(fresh))
                if (fs.Length < 1024 || fs.ReadByte() != 'M' || fs.ReadByte() != 'Z')
                    throw new InvalidDataException("not an .exe");
            if (File.Exists(old)) File.Delete(old);
            File.Move(exe, old);
            try { File.Move(fresh, exe); }
            catch { File.Move(old, exe); throw; }   // put the current version back
        }

        public static void RestartSelf() { Process.Start(ExePath); }

        public static void CleanupSelf()
        {
            try { string old = ExePath + ".old"; if (File.Exists(old)) File.Delete(old); } catch { }
            try { string fresh = ExePath + ".new"; if (File.Exists(fresh)) File.Delete(fresh); } catch { }
        }

        // Marks tools with a newer release. Returns how many have one.
        public static int Check(List<Tool> tools, bool force)
        {
            RateLimited = false;
            var data = force ? null : LoadCache();
            if (data == null)
            {
                var repos = tools.Where(t => t.Tag != null).Select(t => t.Owner + "/" + t.Repo)
                                 .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                var fresh = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);
                var gate = new object();
                Parallel.ForEach(repos, new ParallelOptions { MaxDegreeOfParallelism = 6 }, delegate(string repo)
                {
                    if (RateLimited) return;
                    var r = Fetch(repo);
                    if (r != null) lock (gate) { fresh[repo] = r; }
                });
                if (!RateLimited) SaveCache(fresh);
                data = fresh;
            }

            int n = 0;
            foreach (var t in tools)
            {
                string latestTag = null, latestUrl = null;
                string[] r;
                if (t.Tag != null && data.TryGetValue(t.Owner + "/" + t.Repo, out r) && IsNewer(r[0], t.Tag))
                {
                    latestTag = r[0];
                    latestUrl = MatchAsset(t.Asset, r.Skip(1).ToList());
                    n++;
                }
                t.LatestUrl = latestUrl;
                t.LatestTag = latestTag;
            }
            return n;
        }

        static string[] Fetch(string repo)
        {
            try
            {
                var req = (HttpWebRequest)WebRequest.Create("https://api.github.com/repos/" + repo + "/releases/latest");
                req.UserAgent = "SSTool";
                req.Accept = "application/vnd.github+json";
                req.Timeout = 10000; req.ReadWriteTimeout = 10000;
                string body;
                using (var resp = req.GetResponse())
                using (var sr = new StreamReader(resp.GetResponseStream()))
                    body = sr.ReadToEnd();
                var m = TagRx.Match(body);
                if (!m.Success) return null;
                var list = new List<string> { m.Groups[1].Value };
                foreach (Match a in AssetRx.Matches(body)) list.Add(a.Groups[1].Value);
                return list.ToArray();
            }
            catch (WebException ex)
            {
                var hr = ex.Response as HttpWebResponse;
                if (hr != null && ((int)hr.StatusCode == 403 || (int)hr.StatusCode == 429)) RateLimited = true;
                return null;
            }
            catch { return null; }
        }

        // Only numeric versions are compared; tags like "RL" or "fork" never count as updates.
        static bool IsNewer(string latest, string pinned)
        {
            if (string.Equals(latest, pinned, StringComparison.OrdinalIgnoreCase)) return false;
            Version a = Ver(latest), b = Ver(pinned);
            return a != null && b != null && a > b;
        }

        static Version Ver(string tag)
        {
            var m = NumRx.Match(tag);
            if (!m.Success) return null;
            var parts = m.Value.Split('.').Take(4).ToList();
            while (parts.Count < 4) parts.Add("0");   // so 1.0 == 1.0.0
            Version v;
            return Version.TryParse(string.Join(".", parts.ToArray()), out v) ? v : null;
        }

        // Same file name as the pinned asset, or the same name once version numbers are stripped.
        static string MatchAsset(string asset, List<string> urls)
        {
            var exact = urls.FirstOrDefault(u => string.Equals(FileOf(u), asset, StringComparison.OrdinalIgnoreCase));
            if (exact != null) return exact;
            string sk = Skeleton(asset);
            return urls.FirstOrDefault(u => Skeleton(FileOf(u)) == sk);
        }

        static string FileOf(string url) { return Uri.UnescapeDataString(url.Substring(url.LastIndexOf('/') + 1)); }
        static string Skeleton(string s) { return Regex.Replace(s.ToLowerInvariant(), @"[\d\.\-_]+", ""); }

        static Dictionary<string, string[]> LoadCache()
        {
            try
            {
                if (!File.Exists(CacheFile)) return null;
                var lines = File.ReadAllLines(CacheFile);
                long ticks;
                if (lines.Length == 0 || !long.TryParse(lines[0], out ticks)) return null;
                if (DateTime.UtcNow - new DateTime(ticks, DateTimeKind.Utc) > TimeSpan.FromHours(6)) return null;
                var d = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);
                foreach (var line in lines.Skip(1))
                {
                    var p = line.Split('\t');
                    if (p.Length >= 2) d[p[0]] = p.Skip(1).ToArray();
                }
                return d;
            }
            catch { return null; }
        }

        static void SaveCache(Dictionary<string, string[]> d)
        {
            try
            {
                Directory.CreateDirectory(Settings.Dir);
                var lines = new List<string> { DateTime.UtcNow.Ticks.ToString() };
                foreach (var kv in d) lines.Add(kv.Key + "\t" + string.Join("\t", kv.Value));
                File.WriteAllLines(CacheFile, lines);
            }
            catch { }
        }
    }

    public class MainWindow : Window
    {
        readonly List<Tool> _tools = Data.All();
        readonly List<string> _sections = Data.Sections();
        string _current;
        string _query = "";
        bool _searchOpen;
        ResourceDictionary _styles;

        Grid _rootGrid;
        TextBox _search;
        Border _searchBox;
        Grid _grid;
        TextBlock _secInfo, _secTitle;
        Border _secBand;
        Button _dlAll;
        StackPanel _tabHost;
        Button _maxBtn;
        Border _runBar;
        WrapPanel _runHost;
        StackPanel _toastHost;
        Action _closeOverlay;   // set while the download menu or settings is open

        // Cards currently on screen, plus hooks to relaunch them / redraw their update badge.
        readonly List<FrameworkElement> _cards = new List<FrameworkElement>();
        readonly Dictionary<Tool, Action> _cardLaunch = new Dictionary<Tool, Action>();
        readonly Dictionary<Tool, Action> _cardBadge = new Dictionary<Tool, Action>();
        List<Tool> _shown = new List<Tool>();
        int _cols;

        public MainWindow()
        {
            Title = "SSTool";
            Width = 1000; Height = 680;
            MinWidth = 640; MinHeight = 440;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;   // removes the native white top edge
            ResizeMode = ResizeMode.CanResize;
            Background = Theme.SpaceBg();
            // Borderless windows lose their resize edges; WindowChrome gives them back.
            WindowChrome.SetWindowChrome(this, new WindowChrome
            {
                CaptionHeight = 0,
                ResizeBorderThickness = new Thickness(6),
                GlassFrameThickness = new Thickness(0),
                CornerRadius = new CornerRadius(0),
                UseAeroCaptionButtons = false
            });
            _current = _sections[0];

            SourceInitialized += delegate
            {
                var src = HwndSource.FromHwnd(new WindowInteropHelper(this).Handle);
                if (src != null) src.AddHook(WndProc);
            };
            StateChanged += delegate
            {
                if (_maxBtn != null) _maxBtn.Content = WindowState == WindowState.Maximized ? "" : "";
            };
            PreviewKeyDown += OnKey;
            Engine.Changed += delegate { Dispatcher.BeginInvoke((Action)RefreshRunning); };
            Closed += delegate { Engine.WipeAll(); };
            Loaded += delegate { CheckUpdates(false); };

            Build();
        }

        // (Re)creates the whole UI; used at start and when language/animations change.
        void Build()
        {
            _closeOverlay = null;
            // Theme may have changed: background and accent-tinted styles follow it.
            Background = Theme.SpaceBg();
            if (_styles != null) Resources.MergedDictionaries.Remove(_styles);
            _styles = LoadStyles();
            if (_styles != null) Resources.MergedDictionaries.Add(_styles);
            _rootGrid = new Grid();
            _rootGrid.Children.Add(BuildBackground());   // starfield, behind everything

            var root = new DockPanel();
            root.Children.Add(BuildTitleBar());   // top
            root.Children.Add(BuildTabBar());     // top
            root.Children.Add(BuildRunBar());     // bottom
            root.Children.Add(BuildContent());    // fill
            _rootGrid.Children.Add(root);

            // Top-right, under the tab bar: card tooltips open below the cursor, so they no longer cover toasts.
            _toastHost = new StackPanel
            {
                Width = 330, HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 160, 18, 0)
            };
            _rootGrid.Children.Add(_toastHost);
            Content = _rootGrid;

            RenderSection();
            RefreshRunning();
        }

        // ---------- Maximize to the monitor's work area (not over the taskbar) ----------
        [StructLayout(LayoutKind.Sequential)] struct POINT { public int X, Y; }
        [StructLayout(LayoutKind.Sequential)] struct MINMAXINFO { public POINT ptReserved, ptMaxSize, ptMaxPosition, ptMinTrackSize, ptMaxTrackSize; }
        [StructLayout(LayoutKind.Sequential)] struct RECT { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential)] struct MONITORINFO { public int cbSize; public RECT rcMonitor, rcWork; public int dwFlags; }
        [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr hwnd, int flags);
        [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFO info);

        IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            const int WM_GETMINMAXINFO = 0x0024, MONITOR_DEFAULTTONEAREST = 2;
            if (msg == WM_GETMINMAXINFO)
            {
                var mmi = (MINMAXINFO)Marshal.PtrToStructure(lParam, typeof(MINMAXINFO));
                IntPtr mon = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
                var mi = new MONITORINFO();
                mi.cbSize = Marshal.SizeOf(typeof(MONITORINFO));
                if (mon != IntPtr.Zero && GetMonitorInfo(mon, ref mi))
                {
                    mmi.ptMaxPosition.X = mi.rcWork.Left - mi.rcMonitor.Left;
                    mmi.ptMaxPosition.Y = mi.rcWork.Top - mi.rcMonitor.Top;
                    mmi.ptMaxSize.X = mi.rcWork.Right - mi.rcWork.Left;
                    mmi.ptMaxSize.Y = mi.rcWork.Bottom - mi.rcWork.Top;
                    Marshal.StructureToPtr(mmi, lParam, true);
                }
            }
            return IntPtr.Zero;
        }

        void ToggleMaximize()
        {
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }

        // ---------- Keyboard shortcuts ----------
        void OnKey(object sender, KeyEventArgs e)
        {
            bool ctrl = (Keyboard.Modifiers & ModifierKeys.Control) != 0;
            if (ctrl && e.Key == Key.F) { SetSearch(true); e.Handled = true; return; }
            if (e.Key == Key.Escape)
            {
                if (_closeOverlay != null) _closeOverlay();
                else if (_searchOpen) SetSearch(false);
                e.Handled = true;
                return;
            }
            if (e.Key == Key.Enter && _searchOpen && _search.IsKeyboardFocused && _closeOverlay == null && _shown.Count > 0)
            {
                Action launch;
                if (_cardLaunch.TryGetValue(_shown[0], out launch)) launch();
                e.Handled = true;
                return;
            }
            if (ctrl && e.Key >= Key.D1 && e.Key <= Key.D9 && _closeOverlay == null)
            {
                int i = e.Key - Key.D1;
                if (i < _sections.Count) SelectSection(_sections[i]);
                e.Handled = true;
            }
        }

        // ---------- Animated background: starfield + shooting stars ----------
        static readonly Random _rnd = new Random();

        UIElement BuildBackground()
        {
            bool full = !Settings.Reduced;
            var host = new Canvas { IsHitTestVisible = false, ClipToBounds = true };

            // Two faint nebula glows for depth.
            var neb1 = Nebula(640, Theme.Hex("#1e3a8a"), 0.22, full);
            var neb2 = Nebula(560, Theme.Hex("#6d28d9"), 0.16, full);
            host.Children.Add(neb1);
            host.Children.Add(neb2);

            // Twinkling stars. Positions are fractions of the window, so they always cover it.
            var stars = new List<Ellipse>();
            int count = full ? 140 : 45;
            for (int i = 0; i < count; i++)
            {
                double s = 0.6 + _rnd.NextDouble() * 2.2;
                var star = new Ellipse { Width = s, Height = s, Fill = Brushes.White };
                star.Tag = new Point(_rnd.NextDouble(), _rnd.NextDouble());
                double lo = 0.12 + _rnd.NextDouble() * 0.2;
                double hi = 0.6 + _rnd.NextDouble() * 0.4;
                star.Opacity = full ? lo : (lo + hi) / 2;
                if (full)
                {
                    var tw = new DoubleAnimation(lo, hi, new Duration(TimeSpan.FromSeconds(1.1 + _rnd.NextDouble() * 2.6)))
                    {
                        AutoReverse = true,
                        RepeatBehavior = RepeatBehavior.Forever,
                        BeginTime = TimeSpan.FromMilliseconds(_rnd.Next(0, 3000)),
                        EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut }
                    };
                    star.BeginAnimation(UIElement.OpacityProperty, tw);
                }
                stars.Add(star);
                host.Children.Add(star);
            }

            // Shooting stars (the rain), rebuilt for the new size after a resize settles.
            var shooting = new Canvas { IsHitTestVisible = false };
            host.Children.Add(shooting);
            var settle = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
            settle.Tick += delegate { settle.Stop(); BuildShootingStars(shooting, host.ActualWidth, host.ActualHeight); };

            host.SizeChanged += delegate
            {
                double w = host.ActualWidth, h = host.ActualHeight;
                foreach (var st in stars)
                {
                    var p = (Point)st.Tag;
                    Canvas.SetLeft(st, p.X * w);
                    Canvas.SetTop(st, p.Y * h);
                }
                Canvas.SetLeft(neb1, -140); Canvas.SetTop(neb1, -160);
                Canvas.SetLeft(neb2, w * 0.64); Canvas.SetTop(neb2, h * 0.53);
                if (full) { settle.Stop(); settle.Start(); }
            };
            return host;
        }

        Ellipse Nebula(double size, Color c, double peak, bool drift)
        {
            var e = new Ellipse { Width = size, Height = size, IsHitTestVisible = false };
            var rg = new RadialGradientBrush();
            rg.GradientStops.Add(new GradientStop(Color.FromArgb((byte)(peak * 255), c.R, c.G, c.B), 0));
            rg.GradientStops.Add(new GradientStop(Color.FromArgb(0, c.R, c.G, c.B), 1));
            e.Fill = rg;
            if (drift)
            {
                var tt = new TranslateTransform(); e.RenderTransform = tt;
                var ax = new DoubleAnimation(0, 60, new Duration(TimeSpan.FromSeconds(30))) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut } };
                tt.BeginAnimation(TranslateTransform.XProperty, ax);
            }
            return e;
        }

        // Paths were designed for a 1000x680 window; scale them to the real size.
        void BuildShootingStars(Canvas c, double w, double h)
        {
            c.Children.Clear();
            if (w <= 0 || h <= 0) return;
            double kx = w / 1000.0, ky = h / 680.0;
            AddShootingStar(c, 0.0, 7.0, -120 * kx, -40 * ky, 560 * kx, 380 * ky, 120);
            AddShootingStar(c, 2.6, 9.0, 300 * kx, -80 * ky, 520 * kx, 360 * ky, 100);
            AddShootingStar(c, 4.2, 8.0, -60 * kx, 120 * ky, 600 * kx, 300 * ky, 130);
            AddShootingStar(c, 6.1, 11.0, 520 * kx, -60 * ky, 480 * kx, 420 * ky, 95);
            AddShootingStar(c, 8.3, 10.0, 120 * kx, -100 * ky, 640 * kx, 340 * ky, 115);
        }

        void AddShootingStar(Canvas host, double delaySec, double periodSec, double sx, double sy, double dx, double dy, double len)
        {
            var rect = new System.Windows.Shapes.Rectangle { Width = len, Height = 2, RadiusX = 1, RadiusY = 1, Opacity = 0, IsHitTestVisible = false };
            var grad = new LinearGradientBrush { StartPoint = new Point(0, 0.5), EndPoint = new Point(1, 0.5) };
            grad.GradientStops.Add(new GradientStop(Color.FromArgb(0, 255, 255, 255), 0));
            grad.GradientStops.Add(new GradientStop(Color.FromArgb(180, 255, 255, 255), 0.75));
            grad.GradientStops.Add(new GradientStop(Colors.White, 1));
            rect.Fill = grad;
            rect.Effect = new DropShadowEffect { Color = Colors.White, BlurRadius = 6, ShadowDepth = 0, Opacity = 0.7 };

            double angle = Math.Atan2(dy, dx) * 180.0 / Math.PI;
            var rot = new RotateTransform(angle);
            var tt = new TranslateTransform(sx, sy);
            var tgrp = new TransformGroup();
            tgrp.Children.Add(rot); tgrp.Children.Add(tt);
            rect.RenderTransform = tgrp;
            host.Children.Add(rect);

            double travel = 0.85; // seconds to cross
            var begin = TimeSpan.FromSeconds(delaySec);
            var dur = new Duration(TimeSpan.FromSeconds(periodSec));

            var ax = new DoubleAnimationUsingKeyFrames { RepeatBehavior = RepeatBehavior.Forever, BeginTime = begin, Duration = dur };
            ax.KeyFrames.Add(new LinearDoubleKeyFrame(sx, KeyTime.FromTimeSpan(TimeSpan.Zero)));
            ax.KeyFrames.Add(new LinearDoubleKeyFrame(sx + dx, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(travel))));
            ax.KeyFrames.Add(new DiscreteDoubleKeyFrame(sx + dx, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(periodSec))));
            tt.BeginAnimation(TranslateTransform.XProperty, ax);

            var ay = new DoubleAnimationUsingKeyFrames { RepeatBehavior = RepeatBehavior.Forever, BeginTime = begin, Duration = dur };
            ay.KeyFrames.Add(new LinearDoubleKeyFrame(sy, KeyTime.FromTimeSpan(TimeSpan.Zero)));
            ay.KeyFrames.Add(new LinearDoubleKeyFrame(sy + dy, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(travel))));
            ay.KeyFrames.Add(new DiscreteDoubleKeyFrame(sy + dy, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(periodSec))));
            tt.BeginAnimation(TranslateTransform.YProperty, ay);

            var ao = new DoubleAnimationUsingKeyFrames { RepeatBehavior = RepeatBehavior.Forever, BeginTime = begin, Duration = dur };
            ao.KeyFrames.Add(new DiscreteDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.Zero)));
            ao.KeyFrames.Add(new LinearDoubleKeyFrame(1, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(travel * 0.18))));
            ao.KeyFrames.Add(new LinearDoubleKeyFrame(1, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(travel * 0.7))));
            ao.KeyFrames.Add(new LinearDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(travel))));
            ao.KeyFrames.Add(new DiscreteDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(periodSec))));
            rect.BeginAnimation(UIElement.OpacityProperty, ao);
        }

        // ---------- Dark styles: scrollbar, checkbox, context menu, tooltip ----------
        internal const string StylesXaml =
@"<ResourceDictionary xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                     xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
  <Style x:Key='SThumb' TargetType='Thumb'>
    <Setter Property='Template'>
      <Setter.Value>
        <ControlTemplate TargetType='Thumb'>
          <Border x:Name='tb' CornerRadius='5' Background='#2c3b57' Margin='3,2,3,2'/>
          <ControlTemplate.Triggers>
            <Trigger Property='IsMouseOver' Value='True'>
              <Setter TargetName='tb' Property='Background' Value='#3b82f6'/>
            </Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>
  <Style TargetType='ScrollBar'>
    <Setter Property='Background' Value='Transparent'/>
    <Setter Property='Width' Value='12'/>
    <Setter Property='Template'>
      <Setter.Value>
        <ControlTemplate TargetType='ScrollBar'>
          <Grid Background='Transparent'>
            <Track x:Name='PART_Track' IsDirectionReversed='True'>
              <Track.DecreaseRepeatButton>
                <RepeatButton Command='ScrollBar.PageUpCommand' Opacity='0' Focusable='False'/>
              </Track.DecreaseRepeatButton>
              <Track.Thumb>
                <Thumb Style='{StaticResource SThumb}'/>
              </Track.Thumb>
              <Track.IncreaseRepeatButton>
                <RepeatButton Command='ScrollBar.PageDownCommand' Opacity='0' Focusable='False'/>
              </Track.IncreaseRepeatButton>
            </Track>
          </Grid>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
    <Style.Triggers>
      <Trigger Property='Orientation' Value='Horizontal'>
        <Setter Property='Width' Value='Auto'/>
        <Setter Property='Height' Value='12'/>
      </Trigger>
    </Style.Triggers>
  </Style>
  <Style TargetType='CheckBox'>
    <Setter Property='Foreground' Value='#eaf0fb'/>
    <Setter Property='Cursor' Value='Hand'/>
    <Setter Property='Template'>
      <Setter.Value>
        <ControlTemplate TargetType='CheckBox'>
          <StackPanel Orientation='Horizontal' Background='Transparent'>
            <Border x:Name='box' Width='16' Height='16' CornerRadius='4' BorderThickness='1'
                    BorderBrush='#3a4a66' Background='#101a2e' VerticalAlignment='Center'>
              <TextBlock x:Name='mark' Text='&#xE73E;' FontFamily='Segoe MDL2 Assets' FontSize='10'
                         Foreground='White' HorizontalAlignment='Center' VerticalAlignment='Center' Visibility='Collapsed'/>
            </Border>
            <ContentPresenter Margin='9,0,0,0' VerticalAlignment='Center'/>
          </StackPanel>
          <ControlTemplate.Triggers>
            <Trigger Property='IsMouseOver' Value='True'>
              <Setter TargetName='box' Property='BorderBrush' Value='#6ba5ff'/>
            </Trigger>
            <Trigger Property='IsChecked' Value='True'>
              <Setter TargetName='box' Property='Background' Value='#3b82f6'/>
              <Setter TargetName='box' Property='BorderBrush' Value='#3b82f6'/>
              <Setter TargetName='mark' Property='Visibility' Value='Visible'/>
            </Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>
  <Style x:Key='DarkMenu' TargetType='ContextMenu'>
    <Setter Property='OverridesDefaultStyle' Value='True'/>
    <Setter Property='SnapsToDevicePixels' Value='True'/>
    <Setter Property='Template'>
      <Setter.Value>
        <ControlTemplate TargetType='ContextMenu'>
          <Border Background='#F70d1424' BorderBrush='#33ffffff' BorderThickness='1' CornerRadius='10' Padding='5' MinWidth='220'>
            <StackPanel IsItemsHost='True' KeyboardNavigation.DirectionalNavigation='Cycle'/>
          </Border>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>
  <Style x:Key='DarkItem' TargetType='MenuItem'>
    <Setter Property='OverridesDefaultStyle' Value='True'/>
    <Setter Property='Foreground' Value='#eaf0fb'/>
    <Setter Property='Cursor' Value='Hand'/>
    <Setter Property='Template'>
      <Setter.Value>
        <ControlTemplate TargetType='MenuItem'>
          <Border x:Name='bd' Background='Transparent' CornerRadius='6' Padding='10,7,16,7'>
            <StackPanel Orientation='Horizontal'>
              <TextBlock Text='{Binding Tag, RelativeSource={RelativeSource TemplatedParent}}' FontFamily='Segoe MDL2 Assets'
                         FontSize='12' Width='24' VerticalAlignment='Center' Foreground='{TemplateBinding Foreground}'/>
              <ContentPresenter ContentSource='Header' VerticalAlignment='Center' TextBlock.Foreground='{TemplateBinding Foreground}' TextBlock.FontSize='12.5'/>
            </StackPanel>
          </Border>
          <ControlTemplate.Triggers>
            <Trigger Property='IsHighlighted' Value='True'>
              <Setter TargetName='bd' Property='Background' Value='#22ffffff'/>
            </Trigger>
            <Trigger Property='IsEnabled' Value='False'>
              <Setter Property='Foreground' Value='#818ea6'/>
              <Setter Property='Cursor' Value='Arrow'/>
            </Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>
  <Style x:Key='DarkSep' TargetType='Separator'>
    <Setter Property='Template'>
      <Setter.Value>
        <ControlTemplate TargetType='Separator'>
          <Border Height='1' Background='#22ffffff' Margin='6,4,6,4'/>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>
  <Style x:Key='DarkTip' TargetType='ToolTip'>
    <Setter Property='OverridesDefaultStyle' Value='True'/>
    <Setter Property='HasDropShadow' Value='False'/>
    <Setter Property='Template'>
      <Setter.Value>
        <ControlTemplate TargetType='ToolTip'>
          <Border Background='#F70d1424' BorderBrush='#44ffffff' BorderThickness='1' CornerRadius='8' Padding='12,9,12,9' MaxWidth='320'>
            <ContentPresenter/>
          </Border>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>
</ResourceDictionary>";

        static ResourceDictionary LoadStyles()
        {
            try { return (ResourceDictionary)XamlReader.Parse(StylesXaml); }
            catch { return null; }
        }

        Style St(string key)
        {
            return _styles != null && _styles.Contains(key) ? (Style)_styles[key] : null;
        }

        UIElement BuildTitleBar()
        {
            var bar = new Border();
            bar.Background = Theme.Bar;
            bar.Height = 40;
            DockPanel.SetDock(bar, Dock.Top);
            bar.MouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e)
            {
                if (e.ClickCount == 2) { ToggleMaximize(); return; }
                if (e.ButtonState == MouseButtonState.Pressed) try { DragMove(); } catch { }
            };

            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var left = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(14, 0, 0, 0) };
            var badge = Logo.Create(28, !Settings.Reduced);
            badge.VerticalAlignment = VerticalAlignment.Center;
            left.Children.Add(badge);
            var title = new TextBlock { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 0, 0) };
            title.Inlines.Add(new System.Windows.Documents.Run("SSTool ") { Foreground = Theme.Ink, FontWeight = FontWeights.Bold });
            title.Inlines.Add(new System.Windows.Documents.Run(L.T("by")) { Foreground = Theme.Mut, FontSize = 12 });
            left.Children.Add(title);
            g.Children.Add(left);

            var caption = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            // Language switch: shows the current language, click to swap.
            var lang = CaptionBtn(L.Es ? "ES" : "EN", delegate { Settings.Lang = L.Es ? "en" : "es"; ApplySettings(false); }, false);
            lang.FontFamily = new FontFamily("Segoe UI");
            lang.FontSize = 11.5; lang.FontWeight = FontWeights.SemiBold;
            lang.ToolTip = L.T("language");
            caption.Children.Add(lang);
            var gear = CaptionBtn("", delegate { ShowSettings(); }, false);
            gear.ToolTip = L.T("settings");
            caption.Children.Add(gear);
            caption.Children.Add(CaptionBtn("", delegate { WindowState = WindowState.Minimized; }, false));
            _maxBtn = CaptionBtn(WindowState == WindowState.Maximized ? "" : "", ToggleMaximize, false);
            caption.Children.Add(_maxBtn);
            caption.Children.Add(CaptionBtn("", delegate { Close(); }, true));
            Grid.SetColumn(caption, 1);
            g.Children.Add(caption);

            bar.Child = g;
            return bar;
        }

        Button CaptionBtn(string glyph, Action onClick, bool danger)
        {
            var b = new Button { Content = glyph, Width = 44, Height = 40 };
            b.FontFamily = Theme.Icons;
            b.FontSize = 11;
            b.Foreground = Theme.Ink;
            b.Background = Brushes.Transparent;
            b.BorderThickness = new Thickness(0);
            b.Cursor = Cursors.Hand;
            b.Focusable = false;
            b.Template = FlatTemplate(Brushes.Transparent, danger ? Theme.Hex("#e23b4e") : Theme.Hex("#18233a"));
            b.Click += delegate { onClick(); };
            return b;
        }

        UIElement BuildTabBar()
        {
            var outer = new Border { Background = Theme.Bar, BorderBrush = Theme.Line, BorderThickness = new Thickness(0, 0, 0, 1) };
            DockPanel.SetDock(outer, Dock.Top);

            _tabLooks.Clear();
            _tabHost = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(6, 0, 6, 0) };
            _tabHost.Children.Add(SearchToggle());
            foreach (var s in _sections)
                _tabHost.Children.Add(TabButton(s));
            RefreshTabDots();

            // Hover highlight that glides between tabs (behind them), tinted with the hovered tab's colour.
            _tabLayer = new Grid();
            _hoverSlide = null;
            if (!Settings.Reduced)
            {
                _hoverSlide = new Border
                {
                    HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 6, 0, 6), CornerRadius = new CornerRadius(9),
                    Background = new SolidColorBrush(Color.FromArgb(26, Theme.Glow.R, Theme.Glow.G, Theme.Glow.B)), BorderBrush = new SolidColorBrush(Color.FromArgb(60, Theme.Glow.R, Theme.Glow.G, Theme.Glow.B)),
                    BorderThickness = new Thickness(1), Opacity = 0, Width = 0, IsHitTestVisible = false, RenderTransform = new TranslateTransform()
                };
                _tabLayer.Children.Add(_hoverSlide);
                _tabHost.MouseLeave += delegate { Anim(_hoverSlide, UIElement.OpacityProperty, 0, 220); };
            }
            _tabLayer.Children.Add(_tabHost);

            // No visible scrollbar; the mouse wheel scrolls the tabs sideways when they don't fit.
            var sv = new ScrollViewer
            {
                HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden,
                VerticalScrollBarVisibility = ScrollBarVisibility.Disabled
            };
            sv.Content = _tabLayer;
            sv.PreviewMouseWheel += delegate(object s, MouseWheelEventArgs e)
            {
                sv.ScrollToHorizontalOffset(sv.HorizontalOffset - e.Delta / 2.0);
                e.Handled = true;
            };

            // Search box (hidden until toggled), with a placeholder hint.
            _searchBox = new Border { Visibility = _searchOpen ? Visibility.Visible : Visibility.Collapsed, Background = Theme.Card, BorderBrush = Theme.Line, BorderThickness = new Thickness(1), Margin = new Thickness(8, 6, 8, 6), CornerRadius = new CornerRadius(8) };
            var sg = new Grid();
            sg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            sg.ColumnDefinitions.Add(new ColumnDefinition());
            sg.Children.Add(new TextBlock { Text = "", FontFamily = Theme.Icons, FontSize = 12, Foreground = Theme.Mut, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 0, 0) });
            var hint = new TextBlock { Text = L.T("search_ph"), Foreground = Theme.Mut, Opacity = 0.7, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 8, 0), IsHitTestVisible = false };
            _search = new TextBox { Text = _query, Background = Brushes.Transparent, Foreground = Theme.Ink, BorderThickness = new Thickness(0), Margin = new Thickness(8, 6, 8, 6), CaretBrush = Theme.Acc2, VerticalContentAlignment = VerticalAlignment.Center };
            hint.Visibility = _query.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
            _search.TextChanged += delegate
            {
                _query = _search.Text;
                hint.Visibility = _query.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
                RenderSection();
            };
            Grid.SetColumn(hint, 1); Grid.SetColumn(_search, 1);
            sg.Children.Add(hint);
            sg.Children.Add(_search);
            _searchBox.Child = sg;

            var stack = new StackPanel();
            stack.Children.Add(_searchBox);
            stack.Children.Add(sv);
            outer.Child = stack;
            return outer;
        }

        Button SearchToggle()
        {
            var b = MakeTab("\uE721", null, null, Theme.Glow);
            b.ToolTip = "Ctrl+F";
            b.Click += delegate { SetSearch(!_searchOpen); HighlightTabs(); };
            return b;
        }

        void SetSearch(bool open)
        {
            _searchOpen = open;
            _searchBox.Visibility = open ? Visibility.Visible : Visibility.Collapsed;
            if (open)
            {
                _search.Focus();
                _search.SelectAll();
                RenderSection();
            }
            else if (_search.Text.Length > 0) _search.Text = "";   // TextChanged re-renders
            else RenderSection();
        }

        void SelectSection(string section)
        {
            _current = section;
            if (_searchOpen) SetSearch(false);
            else RenderSection();
        }

        Button TabButton(string section)
        {
            var b = MakeTab(null, L.Section(section), section, Theme.SectionColor(section));
            b.Click += delegate { SelectSection(section); };
            return b;
        }

        // One tab of the section bar: a rounded pill tinted with the section colour, a text/icon brush
        // and an underline that grows from the centre. Hover shows half the line, the active tab all of it.
        class TabLook
        {
            public string Section;            // null = the search toggle
            public Color Col;
            public SolidColorBrush Bg, Fg;
            public ScaleTransform Line, IconScale, Press;
            public TranslateTransform Lift;
            public TextBlock Label;
            public DropShadowEffect Glow;
            public Ellipse Dot;               // green: the section has tools with a new version
            public bool Active;
        }
        readonly List<TabLook> _tabLooks = new List<TabLook>();
        Grid _tabLayer;
        Border _hoverSlide;

        void RefreshTabDots()
        {
            foreach (var look in _tabLooks)
                if (look.Dot != null)
                    look.Dot.Visibility = _tools.Any(t => t.Section == look.Section && t.HasUpdate) ? Visibility.Visible : Visibility.Collapsed;
        }

        // Glides the shared hover highlight under tab b.
        void SlideHover(Button b, TabLook look)
        {
            if (_hoverSlide == null || _tabLayer == null) return;
            double x = b.TranslatePoint(new Point(0, 0), _tabLayer).X;
            var tt = (TranslateTransform)_hoverSlide.RenderTransform;
            Color c = look.Col;
            bool hidden = _hoverSlide.Opacity < 0.05;
            if (hidden)
            {
                // Coming from outside the bar: appear in place instead of sliding from the last tab.
                tt.BeginAnimation(TranslateTransform.XProperty, null); tt.X = x;
                _hoverSlide.BeginAnimation(FrameworkElement.WidthProperty, null); _hoverSlide.Width = b.ActualWidth;
            }
            else
            {
                var ease = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.25 };
                tt.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(x, new Duration(TimeSpan.FromMilliseconds(260))) { EasingFunction = ease });
                _hoverSlide.BeginAnimation(FrameworkElement.WidthProperty, new DoubleAnimation(b.ActualWidth, new Duration(TimeSpan.FromMilliseconds(260))) { EasingFunction = ease });
            }
            AnimColor((SolidColorBrush)_hoverSlide.Background, Color.FromArgb(28, c.R, c.G, c.B), hidden ? 0 : 200);
            AnimColor((SolidColorBrush)_hoverSlide.BorderBrush, Color.FromArgb(70, c.R, c.G, c.B), hidden ? 0 : 200);
            Anim(_hoverSlide, UIElement.OpacityProperty, 1, 160);
        }

        Button MakeTab(string glyph, string text, string section, Color col)
        {
            var look = new TabLook
            {
                Section = section, Col = col,
                Bg = new SolidColorBrush(Color.FromArgb(0, col.R, col.G, col.B)),
                Fg = new SolidColorBrush(Theme.Hex("#818ea6")),
                Line = new ScaleTransform(0, 1), IconScale = new ScaleTransform(1, 1),
                Press = new ScaleTransform(1, 1), Lift = new TranslateTransform(0, 0)
            };

            var pill = new Border { CornerRadius = new CornerRadius(9), Background = look.Bg };
            // Section tabs are text only; the search toggle is icon only.
            var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(glyph == null ? 13 : 10, 7, glyph == null ? 13 : 10, 8) };
            if (glyph != null)
            {
                row.Children.Add(new TextBlock
                {
                    Text = glyph, FontFamily = Theme.Icons, FontSize = 12.5, Foreground = look.Fg, VerticalAlignment = VerticalAlignment.Center,
                    RenderTransformOrigin = new Point(0.5, 0.5), RenderTransform = look.IconScale
                });
            }
            if (text != null)
            {
                look.Label = new TextBlock { Text = text, Foreground = look.Fg, FontSize = 13, VerticalAlignment = VerticalAlignment.Center };
                row.Children.Add(look.Label);
            }
            var line = new System.Windows.Shapes.Rectangle
            {
                Height = 2.5, RadiusX = 1.25, RadiusY = 1.25, Fill = new SolidColorBrush(col),
                VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(12, 0, 12, 0),
                RenderTransformOrigin = new Point(0.5, 0.5), RenderTransform = look.Line
            };
            if (!Settings.Reduced)
            {
                look.Glow = new DropShadowEffect { Color = col, BlurRadius = 10, ShadowDepth = 0, Opacity = 0 };
                line.Effect = look.Glow;
            }
            var grid = new Grid();
            grid.Children.Add(pill);
            grid.Children.Add(row);
            grid.Children.Add(line);
            if (section != null)
            {
                look.Dot = new Ellipse
                {
                    Width = 6, Height = 6, Fill = new SolidColorBrush(Theme.Ok), Visibility = Visibility.Collapsed, IsHitTestVisible = false,
                    HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 4, 4, 0)
                };
                grid.Children.Add(look.Dot);
            }

            var tg = new TransformGroup();
            tg.Children.Add(look.Press); tg.Children.Add(look.Lift);
            var b = new Button
            {
                Content = grid, Margin = new Thickness(2, 6, 2, 6), Padding = new Thickness(0), Cursor = Cursors.Hand,
                Focusable = false, Background = Brushes.Transparent, BorderThickness = new Thickness(0),
                RenderTransformOrigin = new Point(0.5, 0.5), RenderTransform = tg,
                Template = FlatTemplate(Brushes.Transparent, Colors.Transparent)
            };
            b.Tag = look;
            b.MouseEnter += delegate { ApplyTab(look, true); SlideHover(b, look); };
            b.MouseLeave += delegate { ApplyTab(look, false); Anim(look.Press, ScaleTransform.ScaleXProperty, 1, 120); Anim(look.Press, ScaleTransform.ScaleYProperty, 1, 120); };
            // A short press-in so the click is felt.
            b.PreviewMouseLeftButtonDown += delegate { Anim(look.Press, ScaleTransform.ScaleXProperty, 0.95, 80); Anim(look.Press, ScaleTransform.ScaleYProperty, 0.95, 80); };
            b.PreviewMouseLeftButtonUp += delegate { Anim(look.Press, ScaleTransform.ScaleXProperty, 1, 140); Anim(look.Press, ScaleTransform.ScaleYProperty, 1, 140); };
            _tabLooks.Add(look);
            return b;
        }

        // Colours/line for a tab in its current state; animated unless animations are reduced.
        void ApplyTab(TabLook t, bool hover)
        {
            Color c = t.Col;
            // With full animations the hover tint comes from the sliding highlight instead.
            byte bgA = t.Active ? (byte)36 : hover && _hoverSlide == null ? (byte)22 : (byte)0;
            Color fg = t.Active || hover ? Lighten(c, t.Active ? 0.15 : 0.3) : Theme.Hex("#818ea6");
            double line = t.Active ? 1 : hover ? 0.45 : 0;
            int ms = Settings.Reduced ? 0 : 180;

            AnimColor(t.Bg, Color.FromArgb(bgA, c.R, c.G, c.B), ms);
            AnimColor(t.Fg, fg, ms);
            Anim(t.Line, ScaleTransform.ScaleXProperty, line, Settings.Reduced ? 0 : 240);
            Anim(t.IconScale, ScaleTransform.ScaleXProperty, hover || t.Active ? 1.12 : 1, ms);
            Anim(t.IconScale, ScaleTransform.ScaleYProperty, hover || t.Active ? 1.12 : 1, ms);
            Anim(t.Lift, TranslateTransform.YProperty, hover && !t.Active ? -1 : 0, ms);
            if (t.Glow != null) Anim(t.Glow, DropShadowEffect.OpacityProperty, t.Active ? 0.8 : 0, ms);
            if (t.Label != null) t.Label.FontWeight = t.Active ? FontWeights.SemiBold : FontWeights.Normal;
        }

        static void AnimColor(SolidColorBrush b, Color to, int ms)
        {
            if (ms <= 0) { b.BeginAnimation(SolidColorBrush.ColorProperty, null); b.Color = to; return; }
            b.BeginAnimation(SolidColorBrush.ColorProperty, new ColorAnimation(to, new Duration(TimeSpan.FromMilliseconds(ms)))
            { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
        }

        // Horizontal gradient: colour c at alpha a on the left, transparent from `end` onwards.
        static Brush Fade(Color c, byte a, double end)
        {
            var g = new LinearGradientBrush { StartPoint = new Point(0, 0.5), EndPoint = new Point(1, 0.5) };
            g.GradientStops.Add(new GradientStop(Color.FromArgb(a, c.R, c.G, c.B), 0));
            g.GradientStops.Add(new GradientStop(Color.FromArgb(0, c.R, c.G, c.B), end));
            g.Freeze(); return g;
        }

        static Color Lighten(Color c, double k)
        {
            return Color.FromRgb((byte)(c.R + (255 - c.R) * k), (byte)(c.G + (255 - c.G) * k), (byte)(c.B + (255 - c.B) * k));
        }

        void HighlightTabs()
        {
            bool global = Query.Length > 0;
            foreach (var child in _tabHost.Children)
            {
                var b = child as Button;
                var look = b != null ? b.Tag as TabLook : null;
                if (look == null) continue;
                bool on = look.Section == null ? _searchOpen : (!global && look.Section == _current);
                if (on == look.Active && b.IsLoaded) continue;
                look.Active = on;
                ApplyTab(look, b.IsMouseOver);
                // If the bar does not fit, scroll it so the active tab is visible.
                if (on && look.Section != null) b.BringIntoView();
            }
        }

        UIElement BuildContent()
        {
            var panel = new DockPanel { Margin = new Thickness(0) };

            // Section header: title and a "info · N tools" line, with the download menu on the right.
            var header = new Grid();
            header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            header.ColumnDefinitions.Add(new ColumnDefinition());
            header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var titles = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(8, 2, 12, 2) };
            _secTitle = new TextBlock { Foreground = Theme.Ink, FontSize = 22, FontWeight = FontWeights.Bold, TextTrimming = TextTrimming.CharacterEllipsis };
            _secInfo = new TextBlock { Foreground = Theme.Mut, FontSize = 12.5, TextTrimming = TextTrimming.CharacterEllipsis, Margin = new Thickness(0, 1, 0, 0) };
            titles.Children.Add(_secTitle);
            titles.Children.Add(_secInfo);
            Grid.SetColumn(titles, 1);
            header.Children.Add(titles);
            _dlAll = AccentButton(L.T("download_menu"));
            _dlAll.HorizontalAlignment = HorizontalAlignment.Right;
            _dlAll.VerticalAlignment = VerticalAlignment.Center;
            _dlAll.Click += delegate { ShowDownloadMenu(); };
            Grid.SetColumn(_dlAll, 2);
            header.Children.Add(_dlAll);
            // Soft band in the section colour that fades to the right, tying the header to the active tab.
            _secBand = new Border
            {
                Margin = new Thickness(12, 12, 12, 4), Padding = new Thickness(8, 6, 8, 6), CornerRadius = new CornerRadius(16),
                BorderThickness = new Thickness(1), Child = header
            };
            DockPanel.SetDock(_secBand, Dock.Top);
            panel.Children.Add(_secBand);

            _grid = new Grid { Margin = new Thickness(12, 0, 12, 18) };
            _grid.SizeChanged += delegate { LayoutCards(); };
            var sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Hidden, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
            sv.Content = _grid;

            var area = new Grid();
            area.Children.Add(sv);

            // Floating "more below" chevron (bounces, fades in/out with scroll position).
            var arrow = new Border
            {
                Width = 34, Height = 34, CornerRadius = new CornerRadius(17),
                Background = new SolidColorBrush(Color.FromArgb(150, 20, 28, 48)),
                BorderBrush = new SolidColorBrush(Color.FromArgb(120, 120, 150, 210)), BorderThickness = new Thickness(1),
                HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(0, 0, 0, 12), IsHitTestVisible = false, Opacity = 0
            };
            arrow.Child = new TextBlock { Text = "", FontFamily = Theme.Icons, FontSize = 13, Foreground = Brushes.White, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            arrow.Effect = new DropShadowEffect { Color = Theme.Glow, BlurRadius = 14, ShadowDepth = 0, Opacity = 0.6 };
            if (!Settings.Reduced)
            {
                var bob = new TranslateTransform();
                arrow.RenderTransform = bob;
                bob.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(0, 5, new Duration(TimeSpan.FromSeconds(0.85))) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut } });
            }
            area.Children.Add(arrow);

            sv.ScrollChanged += delegate
            {
                bool more = sv.ScrollableHeight > 4 && sv.VerticalOffset < sv.ScrollableHeight - 4;
                Anim(arrow, UIElement.OpacityProperty, more ? 1.0 : 0.0, 220);
            };

            panel.Children.Add(area);
            return panel;
        }

        // ---------- "Running" bar: tools SSTool opened, each with a close button ----------
        UIElement BuildRunBar()
        {
            _runBar = new Border { Background = Theme.Bar, BorderBrush = Theme.Line, BorderThickness = new Thickness(0, 1, 0, 0), Padding = new Thickness(14, 7, 14, 7), Visibility = Visibility.Collapsed };
            DockPanel.SetDock(_runBar, Dock.Bottom);
            var dp = new DockPanel();
            var lbl = new TextBlock { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 12, 0), FontSize = 12.5 };
            lbl.Inlines.Add(new System.Windows.Documents.Run("● ") { Foreground = new SolidColorBrush(Theme.Ok) });
            lbl.Inlines.Add(new System.Windows.Documents.Run(L.T("running")) { Foreground = Theme.Mut });
            DockPanel.SetDock(lbl, Dock.Left);
            dp.Children.Add(lbl);
            _runHost = new WrapPanel { VerticalAlignment = VerticalAlignment.Center };
            dp.Children.Add(_runHost);
            _runBar.Child = dp;
            return _runBar;
        }

        void RefreshRunning()
        {
            if (_runHost == null) return;
            var list = Engine.RunningTools();
            _runHost.Children.Clear();
            foreach (var r in list) _runHost.Children.Add(RunChip(r));
            _runBar.Visibility = list.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        UIElement RunChip(Running r)
        {
            Color col = Theme.SectionColor(r.Tool.Section);
            var chip = new Border
            {
                CornerRadius = new CornerRadius(8), Margin = new Thickness(0, 2, 8, 2), Padding = new Thickness(10, 2, 2, 2),
                Background = new SolidColorBrush(Color.FromArgb(28, col.R, col.G, col.B)),
                BorderBrush = new SolidColorBrush(Color.FromArgb(110, col.R, col.G, col.B)), BorderThickness = new Thickness(1)
            };
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            sp.Children.Add(new TextBlock { Text = r.Tool.Name, Foreground = Theme.Ink, FontSize = 12, VerticalAlignment = VerticalAlignment.Center });
            var x = new Button
            {
                Content = "", FontFamily = Theme.Icons, FontSize = 9, Width = 24, Height = 22, Margin = new Thickness(6, 0, 0, 0),
                Foreground = Theme.Mut, Background = Brushes.Transparent, BorderThickness = new Thickness(0), Cursor = Cursors.Hand, Focusable = false,
                Template = FlatTemplate(Brushes.Transparent, Color.FromArgb(150, 226, 59, 78), 6), ToolTip = L.F("close_tool", r.Tool.Name)
            };
            x.Click += delegate
            {
                x.IsEnabled = false;
                string name = r.Tool.Name;
                var th = new Thread(delegate()
                {
                    Engine.Kill(r);
                    Dispatcher.BeginInvoke((Action)delegate { Toast(L.F("tool_closed", name), "info"); });
                });
                th.IsBackground = true; th.Start();
            };
            sp.Children.Add(x);
            chip.Child = sp;
            return chip;
        }

        Button AccentButton(string text)
        {
            var b = new Button { Content = text, Padding = new Thickness(14, 7, 14, 7) };
            b.Foreground = Theme.Acc2;
            b.Background = Brushes.Transparent;
            b.BorderBrush = Theme.Acc;
            b.BorderThickness = new Thickness(1);
            b.Cursor = Cursors.Hand;
            b.FontSize = 12.5;
            b.FontWeight = FontWeights.SemiBold;
            b.Focusable = false;
            b.Template = FlatTemplate(Brushes.Transparent, Color.FromArgb(32, Theme.Glow.R, Theme.Glow.G, Theme.Glow.B), 8);
            return b;
        }

        // Search text when the search box is open ("" otherwise).
        string Query { get { return _searchOpen ? _query.Trim().ToLowerInvariant() : ""; } }

        // Current section, or every section when searching. Every search word must match.
        List<Tool> CurrentTools()
        {
            string q = Query;
            if (q.Length == 0) return _tools.Where(t => t.Section == _current).ToList();
            var words = q.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            return _tools.Where(delegate(Tool t)
            {
                string hay = (t.Name + " " + t.DescEs + " " + t.DescEn + " " + t.Section + " " + L.Section(t.Section)).ToLowerInvariant();
                return words.All(w => hay.Contains(w));
            }).ToList();
        }

        void RenderSection()
        {
            if (_grid == null) return;
            HighlightTabs();
            _grid.Children.Clear(); _grid.RowDefinitions.Clear(); _grid.ColumnDefinitions.Clear();
            _cards.Clear(); _cardLaunch.Clear(); _cardBadge.Clear();
            _cols = 0;

            _shown = CurrentTools();
            bool global = Query.Length > 0;
            Color col = global ? Theme.Glow : Theme.SectionColor(_current);
            var secCol = new SolidColorBrush(col);

            _secBand.Background = Fade(col, 30, 0.75);
            _secBand.BorderBrush = Fade(col, 45, 0.6);
            _secTitle.Text = global ? L.T("search_results") : L.Section(_current);
            _secInfo.Inlines.Clear();
            if (global)
                _secInfo.Inlines.Add(new System.Windows.Documents.Run(L.F("results_all", _shown.Count)) { Foreground = secCol, FontWeight = FontWeights.SemiBold });
            else
            {
                _secInfo.Inlines.Add(new System.Windows.Documents.Run(Data.SectionInfo(_current)) { Foreground = Theme.Mut });
                _secInfo.Inlines.Add(new System.Windows.Documents.Run("   ·   " + L.F("tools_count", _shown.Count)) { Foreground = secCol, FontWeight = FontWeights.SemiBold });
            }

            _dlAll.Foreground = secCol; _dlAll.BorderBrush = secCol;
            _dlAll.Visibility = _shown.Any(t => t.Kind == "dl") ? Visibility.Visible : Visibility.Collapsed;

            if (_shown.Count == 0)
            {
                // Empty state: big icon, message and (when searching) a hint.
                var empty = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(8, 50, 8, 8) };
                empty.Children.Add(new Border
                {
                    Width = 64, Height = 64, CornerRadius = new CornerRadius(20), HorizontalAlignment = HorizontalAlignment.Center,
                    Background = new SolidColorBrush(Color.FromArgb(26, col.R, col.G, col.B)),
                    BorderBrush = new SolidColorBrush(Color.FromArgb(70, col.R, col.G, col.B)), BorderThickness = new Thickness(1),
                    Child = new TextBlock { Text = global ? "" : "", FontFamily = Theme.Icons, FontSize = 26, Foreground = secCol, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center }
                });
                empty.Children.Add(new TextBlock
                {
                    Text = global ? L.F("no_results", _query.Trim()) : L.T("empty_section"),
                    Foreground = Theme.Ink, FontSize = 15, FontWeight = FontWeights.SemiBold, HorizontalAlignment = HorizontalAlignment.Center,
                    TextAlignment = TextAlignment.Center, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 14, 0, 0)
                });
                if (global)
                    empty.Children.Add(new TextBlock { Text = L.T("no_results_hint"), Foreground = Theme.Mut, FontSize = 12.5, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 4, 0, 0) });
                _grid.Children.Add(empty);
                return;
            }

            for (int i = 0; i < _shown.Count; i++)
            {
                var card = Card(_shown[i], i, global);
                _cards.Add(card);
                _grid.Children.Add(card);
            }
            LayoutCards();
        }

        // Columns follow the window width (2 to 5); cards keep their instance, so no re-animation.
        void LayoutCards()
        {
            if (_cards.Count == 0) return;
            double w = _grid.ActualWidth > 0 ? _grid.ActualWidth : (ActualWidth > 0 ? ActualWidth : Width) - 24;
            int cols = Math.Max(2, Math.Min(5, (int)(w / 235)));
            if (cols == _cols) return;
            _cols = cols;

            _grid.ColumnDefinitions.Clear(); _grid.RowDefinitions.Clear();
            for (int c = 0; c < cols; c++)
                _grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            int rows = (_cards.Count + cols - 1) / cols;
            for (int r = 0; r < rows; r++)
                _grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            for (int i = 0; i < _cards.Count; i++)
            {
                Grid.SetColumn(_cards[i], i % cols);
                Grid.SetRow(_cards[i], i / cols);
            }
        }

        static void Anim(IAnimatable target, DependencyProperty prop, double to, int ms)
        {
            var a = new DoubleAnimation(to, new Duration(TimeSpan.FromMilliseconds(ms)))
            { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } };
            target.BeginAnimation(prop, a);
        }

        static string PillText(Tool t)
        {
            return L.T(t.Kind == "web" ? "pill_open" : (IsScript(t) ? "pill_run" : "pill_dl"));
        }

        static bool IsScript(Tool t) { return t.Kind == "ps" || t.Kind == "local"; }

        static string KindGlyph(Tool t)
        {
            return t.Kind == "web" ? "" : (IsScript(t) ? "" : "");
        }

        static string KindLabel(Tool t)
        {
            if (t.Kind == "dl") return L.T(t.Presets.Count > 0 ? "kind_cli" : "kind_dl");
            return L.T("kind_" + t.Kind);
        }

        // Two letters for the card tile: first letter + next capital ("BAMReveal" -> "BA", "PrefetchView" -> "PV").
        static string Initials(string name)
        {
            var letters = name.Where(char.IsLetterOrDigit).ToArray();
            if (letters.Length == 0) return "?";
            char second = '\0';
            for (int i = 1; i < letters.Length; i++)
                if (char.IsUpper(letters[i]) || char.IsDigit(letters[i])) { second = letters[i]; break; }
            if (second == '\0' && letters.Length > 1) second = letters[1];
            return (char.ToUpperInvariant(letters[0]) + (second == '\0' ? "" : second.ToString())).ToString();
        }

        static string SourceOf(Tool t)
        {
            return t.Kind == "local" ? L.T("src_local")
                : (t.Owner != null ? "github.com/" + t.Owner + "/" + t.Repo : new Uri(t.Url).Host);
        }

        static string Mb(long bytes)
        {
            if (bytes < 1048576) return Math.Max(1, bytes / 1024) + " KB";
            return (bytes / 1048576.0).ToString("0.0") + " MB";
        }

        FrameworkElement Card(Tool t, int index, bool global)
        {
            bool full = !Settings.Reduced;
            Color col = Theme.SectionColor(t.Section);
            var colBrush = new SolidColorBrush(col);
            // Ghost button: only text until the card is hovered, so the grid doesn't fill with identical buttons.
            var pillBg = new SolidColorBrush(Color.FromArgb(0, col.R, col.G, col.B));
            var pillIdle = new SolidColorBrush(Lighten(col, 0.25)) { Opacity = 0.75 };
            var scale = new ScaleTransform(1, 1);
            var trans = new TranslateTransform(0, full ? 20 : 0);
            var tg = new TransformGroup();
            tg.Children.Add(scale); tg.Children.Add(trans);
            var b = new Border
            {
                Background = Theme.CardBg(),
                BorderBrush = Theme.Line,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(14),
                Margin = new Thickness(8),
                Padding = new Thickness(16, 15, 16, 14),
                MinHeight = 150,   // grows instead of cutting long descriptions
                Cursor = Cursors.Hand,
                RenderTransformOrigin = new Point(0.5, 0.5),
                RenderTransform = tg,
                Opacity = full ? 0 : 1
            };

            if (full)
            {
                // Staggered entrance: fade + slide up.
                int delay = Math.Min(index, 24) * 34;
                b.Loaded += delegate
                {
                    var fade = new DoubleAnimation(0, 1, new Duration(TimeSpan.FromMilliseconds(420))) { BeginTime = TimeSpan.FromMilliseconds(delay) };
                    var rise = new DoubleAnimation(20, 0, new Duration(TimeSpan.FromMilliseconds(520)))
                    { BeginTime = TimeSpan.FromMilliseconds(delay), EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } };
                    b.BeginAnimation(UIElement.OpacityProperty, fade);
                    trans.BeginAnimation(TranslateTransform.YProperty, rise);
                };
            }

            var dp = new DockPanel { LastChildFill = true };

            // Footer: action pill (doubles as the download progress bar) + version / warning chip.
            var footer = new DockPanel { LastChildFill = false, Margin = new Thickness(0, 12, 0, 0) };
            DockPanel.SetDock(footer, Dock.Bottom);
            string pillText = PillText(t);
            var fill = new Border { HorizontalAlignment = HorizontalAlignment.Left, Width = 0, CornerRadius = new CornerRadius(8), Background = new SolidColorBrush(Color.FromArgb(110, col.R, col.G, col.B)) };
            var pillTb = new TextBlock { Text = pillText, Foreground = pillIdle, FontSize = 11.5, FontWeight = FontWeights.SemiBold, Margin = new Thickness(11, 5, 11, 5) };
            var pillGrid = new Grid();
            pillGrid.Children.Add(fill);
            pillGrid.Children.Add(pillTb);
            var pill = new Border
            {
                CornerRadius = new CornerRadius(8),
                Background = pillBg,
                VerticalAlignment = VerticalAlignment.Center,
                Child = pillGrid
            };
            DockPanel.SetDock(pill, Dock.Left);
            footer.Children.Add(pill);
            bool noRuntime = Engine.MissingRuntime(t);
            string chipText = t.Warning != null ? "⚠ " + t.Warning : t.Tag;
            if (noRuntime)
            {
                // Missing runtime: a yellow pill that takes you to the Dependencies tab instead of launching.
                var rt = new Border
                {
                    CornerRadius = new CornerRadius(6), Padding = new Thickness(7, 2, 8, 3), Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center,
                    Background = new SolidColorBrush(Color.FromArgb(28, Theme.Warn.R, Theme.Warn.G, Theme.Warn.B)),
                    BorderBrush = new SolidColorBrush(Color.FromArgb(90, Theme.Warn.R, Theme.Warn.G, Theme.Warn.B)), BorderThickness = new Thickness(1),
                    ToolTip = L.T("runtime_go"),
                    Child = new TextBlock { Text = "⚠ " + L.T("runtime_missing"), FontSize = 10.5, FontWeight = FontWeights.SemiBold, Foreground = new SolidColorBrush(Theme.Warn) }
                };
                rt.MouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e) { e.Handled = true; SelectSection("Dependencies"); };
                DockPanel.SetDock(rt, Dock.Right);
                footer.Children.Add(rt);
                chipText = null;
            }
            if (chipText != null)
            {
                bool warn = t.Warning != null;
                // Tags like "fork" or "latest" are labels, not versions: show them as a small pill.
                bool label = !warn && !Regex.IsMatch(chipText, @"\d");
                var chip = new TextBlock
                {
                    Text = chipText, FontSize = 10.5, FontFamily = label ? new FontFamily("Segoe UI") : Theme.Mono, VerticalAlignment = VerticalAlignment.Center,
                    Foreground = warn ? new SolidColorBrush(Theme.Warn) : (label ? Theme.Mut : Theme.Dim), TextTrimming = TextTrimming.CharacterEllipsis,
                    MaxWidth = 130
                };
                FrameworkElement chipEl = chip;
                if (label)
                {
                    chip.FontWeight = FontWeights.SemiBold;
                    chipEl = new Border
                    {
                        CornerRadius = new CornerRadius(6), Padding = new Thickness(7, 1, 7, 2), VerticalAlignment = VerticalAlignment.Center,
                        Background = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255)), BorderBrush = Theme.Line, BorderThickness = new Thickness(1),
                        Child = chip
                    };
                }
                chipEl.Margin = new Thickness(8, 0, 0, 0);
                DockPanel.SetDock(chipEl, Dock.Right);
                footer.Children.Add(chipEl);
            }
            dp.Children.Add(footer);

            // Head: monogram tile in the section colour (green dot = new version), then the name and badge.
            var head = new DockPanel { LastChildFill = true };
            var tile = new Border
            {
                Width = 34, Height = 34, CornerRadius = new CornerRadius(10),
                Background = new SolidColorBrush(Color.FromArgb(34, col.R, col.G, col.B)),
                BorderBrush = new SolidColorBrush(Color.FromArgb(70, col.R, col.G, col.B)), BorderThickness = new Thickness(1),
                Child = new TextBlock { Text = Initials(t.Name), FontSize = 12.5, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Lighten(col, 0.2)), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center }
            };
            var updDot = new Ellipse
            {
                Width = 10, Height = 10, Fill = new SolidColorBrush(Theme.Ok), Stroke = Theme.Bg, StrokeThickness = 2,
                HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, -3, -3, 0),
                Effect = new DropShadowEffect { Color = Theme.Ok, BlurRadius = 8, ShadowDepth = 0, Opacity = 0.9 }
            };
            var tileHost = new Grid { Margin = new Thickness(0, 0, 11, 0), VerticalAlignment = VerticalAlignment.Top };
            tileHost.Children.Add(tile);
            tileHost.Children.Add(updDot);
            DockPanel.SetDock(tileHost, Dock.Left);
            head.Children.Add(tileHost);
            var badgeTb = new TextBlock { Foreground = new SolidColorBrush(Theme.Ok), FontSize = 10.5, FontWeight = FontWeights.SemiBold };
            var badge = new Border
            {
                CornerRadius = new CornerRadius(6), Padding = new Thickness(6, 1, 6, 1), Margin = new Thickness(6, 1, 0, 0),
                Background = new SolidColorBrush(Color.FromArgb(38, Theme.Ok.R, Theme.Ok.G, Theme.Ok.B)),
                VerticalAlignment = VerticalAlignment.Top, Child = badgeTb
            };
            DockPanel.SetDock(badge, Dock.Right);
            head.Children.Add(badge);
            // Cards with a newer release keep a green border so they stand out in the grid.
            Brush restBorder = Theme.Line;
            Action refreshBadge = delegate
            {
                badge.Visibility = t.HasUpdate ? Visibility.Visible : Visibility.Collapsed;
                updDot.Visibility = badge.Visibility;
                if (t.HasUpdate) badgeTb.Text = "↑ " + t.LatestTag;
                restBorder = t.HasUpdate ? new SolidColorBrush(Color.FromArgb(110, Theme.Ok.R, Theme.Ok.G, Theme.Ok.B)) : Theme.Line;
                if (!b.IsMouseOver) b.BorderBrush = restBorder;
            };
            refreshBadge();
            _cardBadge[t] = refreshBadge;
            var names = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            names.Children.Add(new TextBlock { Text = t.Name, Foreground = Theme.Ink, FontWeight = FontWeights.SemiBold, FontSize = 14.5, TextTrimming = TextTrimming.CharacterEllipsis });
            // Under the name: the section in search results, the source otherwise.
            var subTb = new TextBlock { Foreground = global ? colBrush : Theme.Dim, FontSize = 11, TextTrimming = TextTrimming.CharacterEllipsis };
            if (global)
            {
                subTb.Inlines.Add(new System.Windows.Documents.Run(L.Section(t.Section)));
            }
            else
            {
                // What kind of tool it is (the source is in the tooltip).
                subTb.Inlines.Add(new System.Windows.Documents.Run(KindGlyph(t) + "  ") { FontFamily = Theme.Icons, FontSize = 9.5 });
                subTb.Inlines.Add(new System.Windows.Documents.Run(KindLabel(t)));
            }
            names.Children.Add(subTb);
            head.Children.Add(names);

            var sp = new StackPanel();
            sp.Children.Add(head);
            // At most two lines; the full text is in the tooltip.
            sp.Children.Add(new TextBlock
            {
                Text = t.Desc, Foreground = Theme.Mut, FontSize = 12, TextWrapping = TextWrapping.Wrap, TextTrimming = TextTrimming.CharacterEllipsis,
                LineHeight = 16, LineStackingStrategy = LineStackingStrategy.BlockLineHeight, MaxHeight = 32,
                Margin = new Thickness(0, 10, 0, 0)
            });
            dp.Children.Add(sp);
            b.Child = dp;

            DropShadowEffect glow = null;
            if (full)
            {
                glow = new DropShadowEffect { Color = col, BlurRadius = 26, ShadowDepth = 0, Opacity = 0 };
                b.Effect = glow;
            }
            bool busy = false;
            var hovBorder = new SolidColorBrush(Color.FromArgb(150, col.R, col.G, col.B));
            b.MouseEnter += delegate
            {
                b.Background = Theme.CardBgHov(); b.BorderBrush = hovBorder;
                if (full)
                {
                    Anim(scale, ScaleTransform.ScaleXProperty, 1.04, 170);
                    Anim(scale, ScaleTransform.ScaleYProperty, 1.04, 170);
                    Anim(glow, DropShadowEffect.OpacityProperty, 0.6, 180);
                }
                if (!busy) { pill.Background = colBrush; pillTb.Foreground = Brushes.White; }
            };
            b.MouseLeave += delegate
            {
                b.Background = Theme.CardBg(); b.BorderBrush = restBorder;
                if (full)
                {
                    Anim(scale, ScaleTransform.ScaleXProperty, 1.0, 220);
                    Anim(scale, ScaleTransform.ScaleYProperty, 1.0, 220);
                    Anim(glow, DropShadowEffect.OpacityProperty, 0.0, 220);
                }
                pill.Background = pillBg; pillTb.Foreground = busy ? (Brush)colBrush : pillIdle;
            };

            Action<long, long> progress = delegate(long done, long total)
            {
                Dispatcher.BeginInvoke((Action)delegate
                {
                    if (!busy) return;
                    if (total > 0)
                    {
                        double f = Math.Min(1.0, (double)done / total);
                        fill.Width = pill.ActualWidth * f;
                        pillTb.Text = done >= total ? L.T("opening") : (int)(f * 100) + "%  ·  " + Mb(done) + " / " + Mb(total);
                    }
                    else pillTb.Text = L.T("downloading") + "  " + Mb(done);
                });
            };

            Action<string, string> download = delegate(string args, string outDir)
            {
                if (busy) return;
                busy = true;
                pill.Background = pillBg; pillTb.Foreground = colBrush;
                pill.MinWidth = 180;
                pillTb.Text = L.T("downloading");
                RunDownload(t, progress, args, outDir, delegate
                {
                    busy = false;
                    fill.Width = 0; pill.MinWidth = 0;
                    pillTb.Text = pillText;
                    if (b.IsMouseOver) { pill.Background = colBrush; pillTb.Foreground = Brushes.White; }
                    else pillTb.Foreground = pillIdle;
                });
            };
            Action launch = delegate
            {
                if (busy) return;
                // Still launch (the check could miss a custom install), but say why it may not open.
                if (Engine.MissingRuntime(t))
                    Toast(L.F("runtime_toast", t.Name), "err", L.T("runtime_go"), delegate { SelectSection("Dependencies"); });
                if (t.Kind != "dl") LaunchSimple(t);
                else if (t.Presets.Count > 0) ShowCommandMenu(t, download);   // CLI tool: pick a command first
                else download(null, null);
            };
            _cardLaunch[t] = launch;

            b.MouseLeftButtonUp += delegate { launch(); };
            b.MouseRightButtonUp += delegate(object s, MouseButtonEventArgs e) { ShowMenu(t, b, launch); e.Handled = true; };

            if (Settings.Tooltips)
            {
                var tip = new ToolTip { Style = St("DarkTip") };
                b.ToolTip = tip;
                ToolTipService.SetInitialShowDelay(b, 700);
                ToolTipService.SetShowDuration(b, 20000);
                b.ToolTipOpening += delegate { tip.Content = TipContent(t); };
                // Ask for the file size as soon as the pointer arrives, so the tooltip usually has it ready.
                if (t.Kind == "dl") b.MouseEnter += delegate { Engine.FetchSize(t.RunUrl, null); };
            }
            return b;
        }

        // Tooltip: version, source and what clicking does.
        UIElement TipContent(Tool t)
        {
            var sp = new StackPanel();
            sp.Children.Add(new TextBlock { Text = t.Name, Foreground = Theme.Ink, FontWeight = FontWeights.SemiBold, FontSize = 13 });
            sp.Children.Add(new TextBlock { Text = t.Desc, Foreground = Theme.Mut, FontSize = 12, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 6) });
            if (t.Tag != null)
            {
                var v = new TextBlock { FontSize = 12, Foreground = Theme.Ink };
                v.Inlines.Add(new System.Windows.Documents.Run(L.F("ctx_version", t.Tag)));
                if (t.HasUpdate) v.Inlines.Add(new System.Windows.Documents.Run("   ↑ " + t.LatestTag) { Foreground = new SolidColorBrush(Theme.Ok), FontWeight = FontWeights.SemiBold });
                sp.Children.Add(v);
            }
            if (t.Warning != null)
                sp.Children.Add(new TextBlock { Text = "⚠ " + t.Warning, Foreground = new SolidColorBrush(Theme.Warn), FontSize = 12, TextWrapping = TextWrapping.Wrap });
            if (Engine.MissingRuntime(t))
                sp.Children.Add(new TextBlock { Text = "⚠ " + L.T("runtime_tip"), Foreground = new SolidColorBrush(Theme.Warn), FontSize = 12, TextWrapping = TextWrapping.Wrap });
            sp.Children.Add(new TextBlock { Text = L.F("tip_source", SourceOf(t)), Foreground = Theme.Ink, FontSize = 12 });
            if (t.Kind == "dl")
            {
                var size = new TextBlock { Foreground = Theme.Ink, FontSize = 12 };
                Action<long> show = delegate(long bytes)
                {
                    size.Text = L.F("tip_size", bytes > 0 ? Mb(bytes) : L.T("size_unknown"));
                };
                long known;
                if (Engine.KnownSize(t.RunUrl, out known)) show(known);
                else
                {
                    size.Text = L.F("tip_size", L.T("size_checking"));
                    Engine.FetchSize(t.RunUrl, delegate(long bytes) { Dispatcher.BeginInvoke((Action)delegate { show(bytes); }); });
                }
                sp.Children.Add(size);
            }
            sp.Children.Add(new TextBlock { Text = L.T("tip_" + t.Kind), Foreground = Theme.Mut, FontSize = 11.5, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 6, 0, 0) });
            if (t.Presets.Count > 0)
                sp.Children.Add(new TextBlock { Text = L.T("tip_cmd"), Foreground = Theme.Mut, FontSize = 11.5, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) });
            sp.Children.Add(new TextBlock { Text = L.T("tip_right"), Foreground = Theme.Mut, FontSize = 11.5, FontStyle = FontStyles.Italic, Margin = new Thickness(0, 2, 0, 0) });
            return sp;
        }

        void LaunchSimple(Tool t)
        {
            try
            {
                if (t.Kind == "web") Engine.Open(t.Url);
                else if (t.Kind == "local")
                {
                    // It first tries GitHub (a few seconds at most): keep the window responsive.
                    var th = new Thread(delegate()
                    {
                        try { Engine.RunLocal(t); }
                        catch (Exception ex)
                        {
                            string msg = ex.Message;
                            Dispatcher.BeginInvoke((Action)delegate { Toast(L.F("err_open", t.Name, msg), "err"); });
                        }
                    });
                    th.IsBackground = true; th.Start();
                }
                else Engine.RunPs(t);
            }
            catch (Exception ex) { Toast(L.F("err_open", t.Name, ex.Message), "err"); }
        }

        void RunDownload(Tool t, Action<long, long> progress, string args, string outDir, Action onDone)
        {
            var th = new Thread(delegate()
            {
                try { Engine.RunTemp(t, progress, args, outDir); }
                catch (Exception ex)
                {
                    string msg = ex.Message;
                    Dispatcher.BeginInvoke((Action)delegate { Toast(L.F("err_open", t.Name, msg), "err"); });
                }
                finally { Dispatcher.BeginInvoke(onDone); }
            });
            th.IsBackground = true;
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        // ---------- Right-click menu on a card ----------
        void ShowMenu(Tool t, FrameworkElement target, Action launch)
        {
            var cm = new ContextMenu { PlacementTarget = target };
            var style = St("DarkMenu");
            if (style != null) cm.Style = style;

            if (t.Tag != null)
            {
                cm.Items.Add(MenuEntry("", L.F("ctx_version", t.Tag), null));
                if (t.HasUpdate)
                    cm.Items.Add(MenuEntry("", L.F("ctx_update", t.LatestTag), delegate { Engine.Open(t.RepoUrl + "/releases/latest"); }));
                cm.Items.Add(MenuSep());
            }
            string runKey = t.Kind == "web" ? "ctx_open" : (IsScript(t) ? "ctx_run" : "ctx_dl");
            cm.Items.Add(MenuEntry(KindGlyph(t), L.T(runKey), launch));
            if (t.Kind == "local") { cm.IsOpen = true; return; }   // bundled: no link to copy
            if (t.Kind == "dl") cm.Items.Add(MenuEntry("", L.T("ctx_save"), delegate { SaveOne(t); }));
            if (t.Kind == "ps") cm.Items.Add(MenuEntry("", L.T("ctx_script"), delegate { Engine.Open(t.Url); }));
            if (t.RepoUrl != null)
                cm.Items.Add(MenuEntry("", L.T("ctx_repo"), delegate { Engine.Open(t.Tag != null ? t.RepoUrl + "/releases" : t.RepoUrl); }));
            cm.Items.Add(MenuEntry("", L.T("ctx_copy"), delegate
            {
                try { Clipboard.SetText(t.RunUrl); Toast(L.T("copied"), "ok"); } catch { }
            }));
            cm.IsOpen = true;
        }

        MenuItem MenuEntry(string glyph, string text, Action onClick)
        {
            var mi = new MenuItem { Header = text, Tag = glyph };
            var style = St("DarkItem");
            if (style != null) mi.Style = style;
            if (onClick == null) mi.IsEnabled = false;
            else mi.Click += delegate
            {
                try { onClick(); } catch (Exception ex) { Toast(ex.Message, "err"); }
            };
            return mi;
        }

        Separator MenuSep()
        {
            var s = new Separator();
            var style = St("DarkSep");
            if (style != null) s.Style = style;
            return s;
        }

        void SaveOne(Tool t)
        {
            Toast(L.T("downloading") + "  " + t.Name, "info");
            var th = new Thread(delegate()
            {
                try
                {
                    string dir = Engine.SaveToDownloads(t, null);
                    Dispatcher.BeginInvoke((Action)delegate
                    {
                        Toast(L.F("saved_one", t.Name, t.Section), "ok", L.T("open_folder"), delegate { Engine.Open(dir); });
                    });
                }
                catch (Exception ex)
                {
                    string msg = ex.Message;
                    Dispatcher.BeginInvoke((Action)delegate { Toast(L.F("err_open", t.Name, msg), "err"); });
                }
            });
            th.IsBackground = true; th.Start();
        }

        // ---------- Overlays (download menu, settings) ----------
        Border OverlayPanel(Color col, double width)
        {
            return new Border
            {
                Width = width,
                CornerRadius = new CornerRadius(16),
                Background = Theme.Panel,
                BorderBrush = new SolidColorBrush(col), BorderThickness = new Thickness(1),
                HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center,
                Padding = new Thickness(18),
                Effect = Settings.Reduced ? null : new DropShadowEffect { Color = col, BlurRadius = 40, ShadowDepth = 0, Opacity = 0.35 }
            };
        }

        // Shows panel over a dimmed backdrop; returns the close action (also bound to Esc).
        Action ShowOverlay(Border panel)
        {
            if (_closeOverlay != null) _closeOverlay();
            var host = _rootGrid;
            var backdrop = new Border { Background = new SolidColorBrush(Color.FromArgb(160, 0, 0, 0)), Opacity = 0 };
            var sc = new ScaleTransform(0.94, 0.94);
            panel.RenderTransformOrigin = new Point(0.5, 0.5); panel.RenderTransform = sc;
            backdrop.Child = panel;

            bool closed = false;
            Action close = null;
            close = delegate
            {
                if (closed) return;
                closed = true;
                if (_closeOverlay == close) _closeOverlay = null;
                var fo = new DoubleAnimation(0, new Duration(TimeSpan.FromMilliseconds(140)));
                fo.Completed += delegate { host.Children.Remove(backdrop); };
                backdrop.BeginAnimation(UIElement.OpacityProperty, fo);
            };
            backdrop.MouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e) { if (e.OriginalSource == backdrop) close(); };

            host.Children.Add(backdrop);
            backdrop.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, new Duration(TimeSpan.FromMilliseconds(160))));
            Anim(sc, ScaleTransform.ScaleXProperty, 1.0, 180);
            Anim(sc, ScaleTransform.ScaleYProperty, 1.0, 180);
            _closeOverlay = close;
            return close;
        }

        // Pick which tools to download, then save them to Downloads\SSTool\<section>.
        void ShowDownloadMenu()
        {
            var list = _shown.Where(t => t.Kind == "dl").ToList();
            if (list.Count == 0) return;
            bool global = Query.Length > 0;
            Color col = global ? Theme.Glow : Theme.SectionColor(_current);
            var colBrush = new SolidColorBrush(col);

            var panel = OverlayPanel(col, 440);
            panel.MaxHeight = 480;
            var dock = new DockPanel { LastChildFill = true };

            // Header
            var head = new TextBlock { Margin = new Thickness(2, 0, 2, 12) };
            head.Inlines.Add(new System.Windows.Documents.Run(L.T("choose_tools") + "  ") { Foreground = Theme.Ink, FontWeight = FontWeights.Bold, FontSize = 16 });
            head.Inlines.Add(new System.Windows.Documents.Run("· " + (global ? L.T("search_results") : L.Section(_current))) { Foreground = colBrush, FontSize = 13, FontWeight = FontWeights.SemiBold });
            DockPanel.SetDock(head, Dock.Top);
            dock.Children.Add(head);

            var checks = new List<CheckBox>();
            var dlBtn = AccentButton(L.T("download"));
            dlBtn.Foreground = colBrush; dlBtn.BorderBrush = colBrush;

            var selAll = new CheckBox { Content = L.T("select_all"), Foreground = Theme.Mut, FontSize = 12.5, Margin = new Thickness(2, 0, 0, 8) };
            DockPanel.SetDock(selAll, Dock.Top);
            dock.Children.Add(selAll);

            // Buttons row (bottom), with the total size of the selection on the left.
            var btns = new DockPanel { LastChildFill = false, Margin = new Thickness(0, 12, 0, 0) };
            var totalTb = new TextBlock { VerticalAlignment = VerticalAlignment.Center, FontSize = 12.5, Margin = new Thickness(2, 0, 12, 0) };
            DockPanel.SetDock(totalTb, Dock.Left);
            btns.Children.Add(totalTb);
            var cancel = AccentButton(L.T("cancel"));
            cancel.Foreground = Theme.Mut; cancel.BorderBrush = Theme.Line; cancel.Margin = new Thickness(0, 0, 8, 0);
            DockPanel.SetDock(dlBtn, Dock.Right);
            DockPanel.SetDock(cancel, Dock.Right);
            btns.Children.Add(dlBtn);
            btns.Children.Add(cancel);
            DockPanel.SetDock(btns, Dock.Bottom);
            dock.Children.Add(btns);

            // Scrollable checkbox list (fills); each row shows its download size on the right.
            var listSp = new StackPanel();
            var sizeLabels = new Dictionary<Tool, TextBlock>();
            foreach (var t in list)
            {
                string label = global ? t.Name + "   ·   " + L.Section(t.Section) : t.Name;
                var cb = new CheckBox { Content = label, Tag = t, Foreground = Theme.Ink, FontSize = 12.5, Margin = new Thickness(2, 5, 2, 5) };
                checks.Add(cb);
                var sizeTb = new TextBlock { FontFamily = Theme.Mono, FontSize = 11, Foreground = Theme.Dim, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(12, 0, 6, 0), Text = "…" };
                sizeLabels[t] = sizeTb;
                var row = new DockPanel();
                DockPanel.SetDock(sizeTb, Dock.Right);
                row.Children.Add(sizeTb);
                row.Children.Add(cb);
                listSp.Children.Add(row);
            }
            var sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = listSp };
            dock.Children.Add(sv);

            Action updateCount = delegate
            {
                int n = checks.Count(c => c.IsChecked == true);
                dlBtn.Content = n > 0 ? L.T("download") + " (" + n + ")" : L.T("download");
                dlBtn.IsEnabled = n > 0;

                // Total of the selection; "≈" while some sizes are still unknown.
                long sum = 0; bool partial = false;
                foreach (var c in checks.Where(c => c.IsChecked == true))
                {
                    long s;
                    if (Engine.KnownSize(((Tool)c.Tag).RunUrl, out s) && s > 0) sum += s; else partial = true;
                }
                totalTb.Inlines.Clear();
                if (n == 0) return;
                totalTb.Inlines.Add(new System.Windows.Documents.Run(L.T("total") + " ") { Foreground = Theme.Mut });
                totalTb.Inlines.Add(new System.Windows.Documents.Run((partial ? "≈ " : "") + (sum > 0 ? Mb(sum) : "…")) { Foreground = colBrush, FontWeight = FontWeights.SemiBold });
            };
            foreach (var t in list)
            {
                var tool = t;
                Action<long> show = delegate(long bytes)
                {
                    sizeLabels[tool].Text = bytes > 0 ? Mb(bytes) : "—";
                    updateCount();
                };
                long known;
                if (Engine.KnownSize(tool.RunUrl, out known)) show(known);
                else Engine.FetchSize(tool.RunUrl, delegate(long bytes) { Dispatcher.BeginInvoke((Action)delegate { show(bytes); }); });
            }
            foreach (var cb in checks) { cb.Checked += delegate { updateCount(); }; cb.Unchecked += delegate { updateCount(); }; }
            selAll.Checked += delegate { foreach (var c in checks) c.IsChecked = true; };
            selAll.Unchecked += delegate { foreach (var c in checks) c.IsChecked = false; };
            updateCount();

            panel.Child = dock;
            var close = ShowOverlay(panel);
            cancel.Click += delegate { close(); };

            dlBtn.Click += delegate
            {
                var chosen = checks.Where(c => c.IsChecked == true).Select(c => (Tool)c.Tag).ToList();
                if (chosen.Count == 0) return;
                dlBtn.IsEnabled = false; cancel.IsEnabled = false; dlBtn.Content = L.T("downloading");
                bool oneSection = chosen.Select(t => t.Section).Distinct().Count() == 1;
                string folder = oneSection ? Path.Combine(Engine.DownloadsRoot, chosen[0].Section) : Engine.DownloadsRoot;
                var th = new Thread(delegate()
                {
                    int ok = 0; var fails = new List<string>();
                    for (int i = 0; i < chosen.Count; i++)
                    {
                        string step = (i + 1) + "/" + chosen.Count;
                        Action<long, long> prog = delegate(long done, long total)
                        {
                            string pct = total > 0 ? "  ·  " + (int)(100.0 * done / total) + "%" : "  ·  " + Mb(done);
                            Dispatcher.BeginInvoke((Action)delegate { dlBtn.Content = step + pct; });
                        };
                        try { Engine.SaveToDownloads(chosen[i], prog); ok++; }
                        catch { fails.Add(chosen[i].Name); }
                    }
                    Dispatcher.BeginInvoke((Action)delegate
                    {
                        close();
                        if (ok > 0) Toast(L.F("saved_many", ok), "ok", L.T("open_folder"), delegate { Engine.Open(folder); });
                        if (fails.Count > 0) Toast(L.F("failed", string.Join(", ", fails.ToArray())), "err");
                    });
                });
                th.IsBackground = true; th.Start();
            };
        }

        // CLI tools: pick a ready-made command (editable), then download and run it in a console.
        void ShowCommandMenu(Tool t, Action<string, string> run)
        {
            Color col = Theme.SectionColor(t.Section);
            var colBrush = new SolidColorBrush(col);
            string outDir = Path.Combine(Engine.ResultsRoot, t.Name.Replace(' ', '_') + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));

            var panel = OverlayPanel(col, 560);
            var sp = new StackPanel();
            var head = new TextBlock { Margin = new Thickness(2, 0, 2, 4) };
            head.Inlines.Add(new System.Windows.Documents.Run(L.F("cmd_title", t.Name) + "  ") { Foreground = Theme.Ink, FontWeight = FontWeights.Bold, FontSize = 16 });
            head.Inlines.Add(new System.Windows.Documents.Run("· " + L.Section(t.Section)) { Foreground = colBrush, FontSize = 13, FontWeight = FontWeights.SemiBold });
            sp.Children.Add(head);
            sp.Children.Add(new TextBlock { Text = L.T("cmd_pick"), Foreground = Theme.Mut, FontSize = 12.5, Margin = new Thickness(2, 8, 2, 6) });

            var box = new TextBox
            {
                FontFamily = new FontFamily("Consolas"), FontSize = 12.5, Foreground = Theme.Ink, CaretBrush = Theme.Acc2,
                Background = new SolidColorBrush(Theme.Hex("#0a111f")), BorderBrush = Theme.Line, BorderThickness = new Thickness(1),
                Padding = new Thickness(8, 7, 8, 7), TextWrapping = TextWrapping.Wrap
            };

            // One selectable row per preset; picking one fills the command box.
            var rows = new List<Border>();
            Action<int> select = null;
            select = delegate(int idx)
            {
                for (int k = 0; k < rows.Count; k++)
                {
                    rows[k].BorderBrush = k == idx ? colBrush : Theme.Line;
                    rows[k].Background = k == idx ? new SolidColorBrush(Color.FromArgb(30, col.R, col.G, col.B)) : Brushes.Transparent;
                }
                box.Text = t.Presets[idx].Args.Replace("{out}", outDir);
            };
            for (int i = 0; i < t.Presets.Count; i++)
            {
                int idx = i;
                var row = new Border
                {
                    CornerRadius = new CornerRadius(8), BorderThickness = new Thickness(1), Padding = new Thickness(12, 8, 12, 8),
                    Margin = new Thickness(0, 0, 0, 6), Cursor = Cursors.Hand,
                    Child = new TextBlock { Text = t.Presets[i].Label, Foreground = Theme.Ink, FontSize = 12.5, TextWrapping = TextWrapping.Wrap }
                };
                row.MouseLeftButtonUp += delegate { select(idx); };
                rows.Add(row);
                sp.Children.Add(row);
            }

            sp.Children.Add(new TextBlock { Text = L.T("cmd_line"), Foreground = Theme.Mut, FontSize = 12.5, Margin = new Thickness(2, 10, 2, 6) });
            sp.Children.Add(box);
            sp.Children.Add(new TextBlock { Text = L.T("cmd_out"), Foreground = Theme.Mut, FontSize = 11.5, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(2, 8, 2, 0) });

            var btns = new DockPanel { Margin = new Thickness(0, 16, 0, 0), LastChildFill = false };
            var consoleOnly = AccentButton(L.T("cmd_console"));
            consoleOnly.Foreground = Theme.Mut; consoleOnly.BorderBrush = Theme.Line;
            DockPanel.SetDock(consoleOnly, Dock.Left);
            btns.Children.Add(consoleOnly);
            var go = AccentButton(L.T("cmd_run") + "  ▶");
            go.Foreground = colBrush; go.BorderBrush = colBrush;
            DockPanel.SetDock(go, Dock.Right);
            btns.Children.Add(go);
            var cancel = AccentButton(L.T("cancel"));
            cancel.Foreground = Theme.Mut; cancel.BorderBrush = Theme.Line; cancel.Margin = new Thickness(0, 0, 8, 0);
            DockPanel.SetDock(cancel, Dock.Right);
            btns.Children.Add(cancel);
            sp.Children.Add(btns);

            panel.Child = sp;
            var close = ShowOverlay(panel);
            select(0);

            Action runIt = delegate
            {
                string args = box.Text.Trim();
                // Only create (and later open) the results folder if the command writes there.
                string target = args.Contains(outDir) ? outDir : null;
                if (target != null) { try { Directory.CreateDirectory(target); } catch { } }
                close();
                run(args, target);
            };
            go.Click += delegate { runIt(); };
            box.KeyDown += delegate(object s, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; runIt(); } };
            cancel.Click += delegate { close(); };
            consoleOnly.Click += delegate { close(); run(null, null); };
        }

        void ShowSettings()
        {
            var panel = OverlayPanel(Theme.Glow, 440);
            var sp = new StackPanel();
            sp.Children.Add(new TextBlock { Text = L.T("settings"), Foreground = Theme.Ink, FontWeight = FontWeights.Bold, FontSize = 16, Margin = new Thickness(2, 0, 2, 14) });

            sp.Children.Add(SettingRow(L.T("language"), Segmented("Español", "English", L.Es,
                delegate(bool first) { Settings.Lang = first ? "es" : "en"; ApplySettings(true); })));
            sp.Children.Add(SettingRow(L.T("animations"), Segmented(L.T("anim_full"), L.T("anim_reduced"), !Settings.Reduced,
                delegate(bool first) { Settings.Reduced = !first; ApplySettings(true); })));
            sp.Children.Add(SettingRow(L.T("tooltips"), Segmented(L.T("yes"), L.T("no"), Settings.Tooltips,
                delegate(bool first) { Settings.Tooltips = first; ApplySettings(true); })));
            var upd = AccentButton(L.T("check_updates"));
            sp.Children.Add(SettingRow(L.T("updates"), upd));
            // This build's version, or a button when a newer SSTool was found.
            if (Updates.SelfUrl != null)
            {
                var selfBtn = AccentButton(L.F("self_update_to", Updates.SelfTag));
                selfBtn.Foreground = new SolidColorBrush(Theme.Ok);
                selfBtn.BorderBrush = new SolidColorBrush(Theme.Ok);
                selfBtn.Click += delegate { UpdateSelf(); };
                sp.Children.Add(SettingRow(L.T("self_version") + "  v" + Updates.AppVersion, selfBtn));
            }
            else
                sp.Children.Add(SettingRow(L.T("self_version"), new TextBlock { Text = "v" + Updates.AppVersion + "  ·  " + L.T("self_latest"), Foreground = Theme.Ink, FontSize = 13 }));

            sp.Children.Add(new TextBlock { Text = L.T("shortcuts"), Foreground = Theme.Ink, FontWeight = FontWeights.SemiBold, FontSize = 13, Margin = new Thickness(2, 16, 2, 6) });
            sp.Children.Add(new TextBlock { Text = L.T("shortcuts_text"), Foreground = Theme.Mut, FontSize = 12, LineHeight = 20, Margin = new Thickness(2, 0, 2, 0) });

            var closeBtn = AccentButton(L.T("close"));
            closeBtn.HorizontalAlignment = HorizontalAlignment.Right;
            closeBtn.Margin = new Thickness(0, 16, 0, 0);
            sp.Children.Add(closeBtn);

            panel.Child = sp;
            var close = ShowOverlay(panel);
            closeBtn.Click += delegate { close(); };
            upd.Click += delegate { close(); CheckUpdates(true); };
        }

        UIElement SettingRow(string label, UIElement control)
        {
            var g = new Grid { Margin = new Thickness(2, 0, 0, 10) };
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.Children.Add(new TextBlock { Text = label, Foreground = Theme.Mut, FontSize = 13, VerticalAlignment = VerticalAlignment.Center });
            Grid.SetColumn(control, 1);
            g.Children.Add(control);
            return g;
        }

        // Two-option switch; pick(true) = first option chosen.
        UIElement Segmented(string a, string b, bool firstOn, Action<bool> pick)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            for (int i = 0; i < 2; i++)
            {
                bool first = i == 0;
                bool on = first == firstOn;
                var btn = AccentButton(first ? a : b);
                btn.MinWidth = 92;
                btn.Margin = new Thickness(first ? 0 : 6, 0, 0, 0);
                if (on) { btn.Background = Theme.Acc; btn.Foreground = Brushes.White; }
                else { btn.Foreground = Theme.Mut; btn.BorderBrush = Theme.Line; btn.Click += delegate { pick(first); }; }
                sp.Children.Add(btn);
            }
            return sp;
        }

        void ApplySettings(bool reopenSettings)
        {
            Settings.Save();
            Build();
            if (reopenSettings) ShowSettings();
        }

        // ---------- Update check (GitHub releases) ----------
        void CheckUpdates(bool force)
        {
            if (force) Toast(L.T("checking"), "info");
            var th = new Thread(delegate()
            {
                int n = 0;
                bool self = false;
                try { n = Updates.Check(_tools, force); } catch { }
                try { self = Updates.CheckSelf(); } catch { }
                Dispatcher.BeginInvoke((Action)delegate
                {
                    foreach (var refresh in _cardBadge.Values) refresh();
                    RefreshTabDots();
                    if (self) Toast(L.F("self_available", Updates.SelfTag, "v" + Updates.AppVersion), "update", L.T("self_update"), UpdateSelf);
                    if (Updates.RateLimited) { if (force) Toast(L.T("update_limit"), "err"); }
                    else if (n > 0) Toast(L.F("updates_found", n), "info");
                    else if (force && !self) Toast(L.T("up_to_date"), "ok");
                });
            });
            th.IsBackground = true; th.Start();
        }

        // Downloads the new SSTool, swaps the exe and restarts into it.
        bool _selfUpdating;
        void UpdateSelf()
        {
            if (_selfUpdating || Updates.SelfUrl == null) return;
            _selfUpdating = true;
            Toast(L.F("self_downloading", Updates.SelfTag), "info");
            var th = new Thread(delegate()
            {
                try
                {
                    Updates.ApplySelf(null);
                    Dispatcher.BeginInvoke((Action)delegate
                    {
                        try { Updates.RestartSelf(); } catch { }
                        Close();
                    });
                }
                catch (Exception ex)
                {
                    Dispatcher.BeginInvoke((Action)delegate { _selfUpdating = false; Toast(L.F("self_failed", ex.Message), "err"); });
                }
            });
            th.IsBackground = true; th.Start();
        }

        // ---------- Toast notifications (replace MessageBox) ----------
        void Toast(string text, string kind, string actionText = null, Action action = null)
        {
            var host = _toastHost;
            if (host == null) return;
            // "update" = a new SSTool version: green, stays longer so the button can be clicked.
            Color c = kind == "ok" || kind == "update" ? Theme.Ok : (kind == "err" ? Theme.Bad : Theme.Glow);
            string glyph = kind == "ok" ? "" : (kind == "err" ? "" : "");

            var tr = new TranslateTransform(40, 0);
            var box = new Border
            {
                Background = Theme.Panel,
                BorderBrush = new SolidColorBrush(Color.FromArgb(150, c.R, c.G, c.B)), BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(10), Padding = new Thickness(12, 10, 6, 10), Margin = new Thickness(0, 8, 0, 0),
                Opacity = 0, RenderTransform = tr
            };
            if (!Settings.Reduced) box.Effect = new DropShadowEffect { Color = c, BlurRadius = 24, ShadowDepth = 0, Opacity = 0.3 };

            var dp = new DockPanel();
            var ic = new TextBlock { Text = glyph, FontFamily = Theme.Icons, FontSize = 14, Foreground = new SolidColorBrush(c), Margin = new Thickness(0, 1, 10, 0), VerticalAlignment = VerticalAlignment.Top };
            DockPanel.SetDock(ic, Dock.Left);
            dp.Children.Add(ic);
            var x = new Button
            {
                Content = "", FontFamily = Theme.Icons, FontSize = 9, Width = 24, Height = 24, VerticalAlignment = VerticalAlignment.Top,
                Foreground = Theme.Mut, Background = Brushes.Transparent, BorderThickness = new Thickness(0), Cursor = Cursors.Hand, Focusable = false,
                Template = FlatTemplate(Brushes.Transparent, Color.FromArgb(24, 255, 255, 255), 6)
            };
            DockPanel.SetDock(x, Dock.Right);
            dp.Children.Add(x);
            var body = new StackPanel();
            body.Children.Add(new TextBlock { Text = text, Foreground = Theme.Ink, FontSize = 12.5, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 4, 0) });
            dp.Children.Add(body);
            box.Child = dp;

            bool gone = false;
            Action dismiss = delegate
            {
                if (gone) return;
                gone = true;
                var fo = new DoubleAnimation(0, new Duration(TimeSpan.FromMilliseconds(200)));
                fo.Completed += delegate { host.Children.Remove(box); };
                box.BeginAnimation(UIElement.OpacityProperty, fo);
            };
            x.Click += delegate { dismiss(); };
            if (actionText != null && action != null)
            {
                var link = new Button
                {
                    Content = actionText, Foreground = new SolidColorBrush(c), FontWeight = FontWeights.SemiBold, FontSize = 12,
                    Background = Brushes.Transparent, BorderThickness = new Thickness(0), Cursor = Cursors.Hand, Focusable = false,
                    Padding = new Thickness(8, 3, 8, 3), Margin = new Thickness(-8, 4, 0, 0), HorizontalAlignment = HorizontalAlignment.Left,
                    Template = FlatTemplate(Brushes.Transparent, Color.FromArgb(30, c.R, c.G, c.B), 6)
                };
                link.Click += delegate
                {
                    try { action(); } catch { }
                    dismiss();
                };
                body.Children.Add(link);
            }

            host.Children.Add(box);
            while (host.Children.Count > 4) host.Children.RemoveAt(0);
            box.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, new Duration(TimeSpan.FromMilliseconds(180))));
            tr.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(40, 0, new Duration(TimeSpan.FromMilliseconds(260))) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });

            // Auto-hide; waits while the mouse is over it.
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(kind == "update" ? 20 : (kind == "err" ? 7 : 4.5)) };
            timer.Tick += delegate
            {
                if (box.IsMouseOver) return;
                timer.Stop();
                dismiss();
            };
            timer.Start();
        }

        // Flat button template: transparent normal, color on hover.
        static ControlTemplate FlatTemplate(Brush normal, Color hover) { return FlatTemplate(normal, hover, 0); }
        static ControlTemplate FlatTemplate(Brush normal, Color hover, double radius)
        {
            var t = new ControlTemplate(typeof(Button));
            var bd = new System.Windows.FrameworkElementFactory(typeof(Border));
            bd.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Control.BackgroundProperty));
            bd.SetValue(Border.BorderBrushProperty, new TemplateBindingExtension(Control.BorderBrushProperty));
            bd.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(Control.BorderThicknessProperty));
            bd.SetValue(Border.CornerRadiusProperty, new CornerRadius(radius));
            bd.SetValue(Border.PaddingProperty, new TemplateBindingExtension(Control.PaddingProperty));
            bd.Name = "bd";
            var cp = new System.Windows.FrameworkElementFactory(typeof(ContentPresenter));
            cp.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            cp.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            cp.SetValue(ContentPresenter.MarginProperty, new Thickness(0));
            bd.AppendChild(cp);
            t.VisualTree = bd;
            var trig = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
            trig.Setters.Add(new Setter(Border.BackgroundProperty, new SolidColorBrush(hover), "bd"));
            t.Triggers.Add(trig);
            var dis = new Trigger { Property = UIElement.IsEnabledProperty, Value = false };
            dis.Setters.Add(new Setter(UIElement.OpacityProperty, 0.5, "bd"));
            t.Triggers.Add(dis);
            return t;
        }
    }

    // Startup splash: the SS logo pops in with a glow while the main window is built behind it.
    public class Splash : Window
    {
        readonly Border _bar;
        readonly bool _full = !Settings.Reduced;

        public Splash()
        {
            Width = 340; Height = 260;
            WindowStyle = WindowStyle.None; AllowsTransparency = true; Background = Brushes.Transparent;
            ResizeMode = ResizeMode.NoResize; WindowStartupLocation = WindowStartupLocation.CenterScreen;
            ShowInTaskbar = false; Topmost = true;

            var card = new Border
            {
                Background = Theme.SpaceBg(), CornerRadius = new CornerRadius(18), Margin = new Thickness(16),
                BorderBrush = new SolidColorBrush(Color.FromArgb(60, 107, 165, 255)), BorderThickness = new Thickness(1),
                Effect = new DropShadowEffect { Color = Colors.Black, BlurRadius = 18, ShadowDepth = 0, Opacity = 0.6 }
            };
            var sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };

            var logoScale = new ScaleTransform(_full ? 0.4 : 1, _full ? 0.4 : 1);
            var logo = Logo.Create(72, _full, _full);
            logo.HorizontalAlignment = HorizontalAlignment.Center;
            logo.Margin = new Thickness(0, 6, 0, 6);   // room for the spinning ring
            logo.RenderTransformOrigin = new Point(0.5, 0.5);
            logo.RenderTransform = logoScale;
            logo.Opacity = _full ? 0 : 1;
            sp.Children.Add(logo);

            var titleMove = new TranslateTransform(0, _full ? 10 : 0);
            var title = new TextBlock { HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 14, 0, 0), Opacity = _full ? 0 : 1, RenderTransform = titleMove };
            title.Inlines.Add(new System.Windows.Documents.Run("SSTool") { Foreground = Theme.Ink, FontSize = 20, FontWeight = FontWeights.Bold });
            sp.Children.Add(title);
            var by = new TextBlock { Text = L.T("by"), Foreground = Theme.Mut, FontSize = 12, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 2, 0, 0), Opacity = _full ? 0 : 1 };
            sp.Children.Add(by);

            // Thin loading bar under the text.
            var track = new Border { Width = 140, Height = 3, CornerRadius = new CornerRadius(1.5), Margin = new Thickness(0, 16, 0, 0), Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)) };
            _bar = new Border { Width = 0, HorizontalAlignment = HorizontalAlignment.Left, CornerRadius = new CornerRadius(1.5), Background = Theme.LogoBg() };
            track.Child = _bar;
            sp.Children.Add(track);

            card.Child = sp;
            Content = card;

            if (_full)
            {
                Opacity = 0;
                Loaded += delegate
                {
                    BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, new Duration(TimeSpan.FromMilliseconds(180))));
                    var pop = new DoubleAnimation(0.4, 1, new Duration(TimeSpan.FromMilliseconds(520))) { EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.5 } };
                    logoScale.BeginAnimation(ScaleTransform.ScaleXProperty, pop);
                    logoScale.BeginAnimation(ScaleTransform.ScaleYProperty, pop);
                    logo.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, new Duration(TimeSpan.FromMilliseconds(260))));
                    var late = TimeSpan.FromMilliseconds(220);
                    title.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, new Duration(TimeSpan.FromMilliseconds(380))) { BeginTime = late });
                    titleMove.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(10, 0, new Duration(TimeSpan.FromMilliseconds(420))) { BeginTime = late, EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
                    by.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, new Duration(TimeSpan.FromMilliseconds(380))) { BeginTime = TimeSpan.FromMilliseconds(360) });
                    _bar.BeginAnimation(WidthProperty, new DoubleAnimation(0, 110, new Duration(TimeSpan.FromMilliseconds(MinMs))) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
                };
            }
        }

        // How long the splash stays at least, so the animation can play.
        public int MinMs { get { return _full ? 1100 : 400; } }

        // Fills the bar, fades out and closes.
        public void Finish()
        {
            if (!_full) { Close(); return; }
            _bar.BeginAnimation(WidthProperty, new DoubleAnimation(140, new Duration(TimeSpan.FromMilliseconds(150))));
            var fade = new DoubleAnimation(0, new Duration(TimeSpan.FromMilliseconds(220))) { BeginTime = TimeSpan.FromMilliseconds(120) };
            fade.Completed += delegate { Close(); };
            BeginAnimation(OpacityProperty, fade);
        }
    }

    public class App : Application
    {
        [STAThread]
        public static void Main()
        {
            // GitHub / NirSoft require TLS 1.2+. .NET Framework defaults to older
            // protocols, which caused "No se puede crear un canal seguro SSL/TLS".
            try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072 | (SecurityProtocolType)12288; }
            catch { try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; } catch { } }
            ServicePointManager.DefaultConnectionLimit = 8;   // parallel update checks

            Settings.Load();
            Updates.CleanupSelf();   // leftovers from a self-update
            var app = new App();
            // Splash first; the main window is built while it animates and shown once both are ready.
            app.ShutdownMode = ShutdownMode.OnExplicitShutdown;
            app.Startup += delegate
            {
                var splash = new Splash();
                splash.Show();
                var shown = Stopwatch.StartNew();
                app.Dispatcher.BeginInvoke(DispatcherPriority.Background, (Action)delegate
                {
                    var w = new MainWindow();
                    app.MainWindow = w;
                    app.ShutdownMode = ShutdownMode.OnMainWindowClose;
                    var wait = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(Math.Max(1, splash.MinMs - shown.ElapsedMilliseconds)) };
                    wait.Tick += delegate
                    {
                        wait.Stop();
                        w.Show();
                        w.Activate();
                        splash.Finish();
                    };
                    wait.Start();
                });
            };
            app.Run();
        }
    }
}
