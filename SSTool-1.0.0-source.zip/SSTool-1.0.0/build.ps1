﻿# Compila SSTool.exe con el compilador de C# del .NET Framework 4.8 (ya instalado).
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$csc  = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
$fw   = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319"
$wpf  = "$fw\WPF"

$args = @(
  "/target:winexe", "/out:$here\SSTool.exe", "/nologo", "/platform:x64",
  "/reference:$wpf\PresentationFramework.dll",
  "/reference:$wpf\PresentationCore.dll",
  "/reference:$wpf\WindowsBase.dll",
  "/reference:$fw\System.Xaml.dll",
  "/reference:System.dll", "/reference:System.Core.dll", "/reference:System.Xml.dll",
  "/reference:System.IO.Compression.dll",
  "/reference:System.IO.Compression.FileSystem.dll",
  "/resource:$here\scripts\NTFS-Artifacts.ps1,NTFS-Artifacts.ps1",
  "/win32manifest:$here\app.manifest",
  "/win32icon:$here\app.ico",
  "$here\SSTool.cs", "$here\Data.cs"
)
& $csc $args
if ($LASTEXITCODE -eq 0) { Write-Host "OK -> $here\SSTool.exe" } else { Write-Host "FALLO ($LASTEXITCODE)" }
